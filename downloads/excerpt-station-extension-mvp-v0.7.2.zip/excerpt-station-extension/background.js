const CONTENT_SCRIPT_FILE = 'content.js';
const OFFSCREEN_DOCUMENT_PATH = 'offscreen.html';
const DEFAULT_ACTION_TITLE = '打开摘录中转站';
const MAX_CLIPBOARD_BYTES = 8 * 1024 * 1024;

let creatingOffscreenDocument = null;

chrome.action.onClicked.addListener(async (tab) => {
  if (tab.id == null) return;
  await clearActionError(tab.id);

  try {
    const response = await chrome.tabs.sendMessage(tab.id, { type: 'EXCERPT_STATION_TOGGLE' });
    if (!response?.ok) throw new Error('现有内容脚本没有响应。');
  } catch (firstError) {
    try {
      await chrome.scripting.insertCSS({
        target: { tabId: tab.id },
        files: ['content-page.css']
      });
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: [CONTENT_SCRIPT_FILE]
      });
      const response = await chrome.tabs.sendMessage(tab.id, { type: 'EXCERPT_STATION_TOGGLE' });
      if (!response?.ok) throw new Error('内容脚本注入后没有响应。');
    } catch (injectionError) {
      console.warn('摘录中转站无法在当前页面运行。', injectionError);
      await showActionError(tab.id);
    }
  }
});

async function clearActionError(tabId) {
  await Promise.all([
    chrome.action.setBadgeText({ tabId, text: '' }),
    chrome.action.setTitle({ tabId, title: DEFAULT_ACTION_TITLE })
  ]);
}

async function showActionError(tabId) {
  await Promise.all([
    chrome.action.setBadgeBackgroundColor({ tabId, color: '#cf3f44' }),
    chrome.action.setBadgeText({ tabId, text: '!' }),
    chrome.action.setTitle({ tabId, title: '摘录中转站：当前页面不支持运行' })
  ]);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.target !== 'service-worker' || message?.type !== 'EXCERPT_STATION_WRITE_CLIPBOARD') {
    return false;
  }

  writeClipboard(message.html, message.text)
    .then(() => sendResponse({ ok: true }))
    .catch((error) => {
      console.error('写入剪贴板失败。', error);
      sendResponse({ ok: false, error: error?.message || String(error) });
    });

  return true;
});

async function writeClipboard(html, text) {
  if (typeof html !== 'string' || typeof text !== 'string') {
    throw new TypeError('剪贴板内容格式无效。');
  }
  if (new TextEncoder().encode(html + text).byteLength > MAX_CLIPBOARD_BYTES) {
    throw new RangeError('剪贴板内容超过 8 MB 限制。');
  }

  await ensureOffscreenDocument();
  const response = await chrome.runtime.sendMessage({
    target: 'offscreen',
    type: 'EXCERPT_STATION_OFFSCREEN_WRITE',
    html,
    text
  });

  if (!response?.ok) {
    throw new Error(response?.error || '离屏剪贴板写入失败。');
  }
}

async function ensureOffscreenDocument() {
  if (!creatingOffscreenDocument) {
    creatingOffscreenDocument = (async () => {
      if (await hasOffscreenDocument()) return;
      await chrome.offscreen.createDocument({
        url: OFFSCREEN_DOCUMENT_PATH,
        reasons: [chrome.offscreen.Reason.CLIPBOARD],
        justification: '将用户勾选的多个网页片段以富文本和纯文本两种格式写入剪贴板。'
      });
    })().finally(() => {
      creatingOffscreenDocument = null;
    });
  }

  await creatingOffscreenDocument;
}

async function hasOffscreenDocument() {
  const documentUrl = chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH);

  if (typeof chrome.runtime.getContexts === 'function') {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
      documentUrls: [documentUrl]
    });
    return contexts.length > 0;
  }

  if (typeof chrome.offscreen.hasDocument === 'function') {
    return chrome.offscreen.hasDocument();
  }

  return false;
}
