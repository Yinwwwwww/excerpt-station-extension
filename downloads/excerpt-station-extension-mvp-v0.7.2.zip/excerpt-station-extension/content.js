(() => {
  if (globalThis.__EXCERPT_STATION_MVP__) return;

  const MAX_SEGMENTS = 50;
  const MAX_TOTAL_BYTES = 8 * 1024 * 1024;
  const CAPTURE_CLICK_SLOP = 8;
  const CARET_MAX_HIT_DISTANCE = 28;
  const CAPTURE_CLASS = 'excerpt-station-capture';
  const SELECTION_COLOR_STORAGE_KEY = 'excerptStationSelectionColor';
  const FLOATING_MODE_STORAGE_KEY = 'excerptStationFloatingMode';
  const DEFAULT_SELECTION_COLOR = '#A9CAFF';
  const DEFAULT_FLOATING_MODE = 'dual';
  const SELECTION_COLORS = new Set(['#A9CAFF', '#FFE46B', '#FF9FA9', '#8FE3C0']);
  const FLOATING_MODES = new Set(['dual', 'single']);
  const SELECTION_HIGHLIGHT_NAMES = {
    '#A9CAFF': 'excerpt-station-selection-blue',
    '#FFE46B': 'excerpt-station-selection-yellow',
    '#FF9FA9': 'excerpt-station-selection-red',
    '#8FE3C0': 'excerpt-station-selection-green'
  };
  const ALLOW_SYNTHETIC_TEST_EVENTS = globalThis.__EXCERPT_STATION_ALLOW_SYNTHETIC_TEST_EVENTS__ === true;
  const isTrustedInteraction = (event) => event.isTrusted || ALLOW_SYNTHETIC_TEST_EVENTS;

  const BLOCKED_TAGS = new Set([
    'SCRIPT', 'STYLE', 'NOSCRIPT', 'IFRAME', 'OBJECT', 'EMBED', 'FORM', 'INPUT',
    'BUTTON', 'TEXTAREA', 'SELECT', 'OPTION', 'META', 'LINK', 'BASE', 'TEMPLATE',
    'SVG', 'MATH', 'CANVAS', 'VIDEO', 'AUDIO'
  ]);

  const ALLOWED_TAGS = new Set([
    'A', 'ABBR', 'B', 'BDI', 'BDO', 'BLOCKQUOTE', 'BR', 'CAPTION', 'CITE', 'CODE',
    'COL', 'COLGROUP', 'DD', 'DEL', 'DIV', 'DL', 'DT', 'EM', 'FIGCAPTION', 'FIGURE',
    'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'HR', 'I', 'IMG', 'KBD', 'LI', 'MARK',
    'OL', 'P', 'PICTURE', 'PRE', 'Q', 'S', 'SAMP', 'SMALL', 'SPAN', 'STRONG', 'SUB',
    'SUMMARY', 'SUP', 'TABLE', 'TBODY', 'TD', 'TFOOT', 'TH', 'THEAD', 'TR', 'U',
    'UL', 'VAR'
  ]);

  const COMMON_ATTRIBUTES = new Set(['style', 'dir', 'lang', 'title']);
  const TAG_ATTRIBUTES = {
    A: new Set(['href']),
    BLOCKQUOTE: new Set(['cite']),
    COL: new Set(['span', 'width']),
    COLGROUP: new Set(['span', 'width']),
    IMG: new Set(['src', 'alt', 'width', 'height']),
    OL: new Set(['start', 'reversed', 'type']),
    Q: new Set(['cite']),
    TD: new Set(['colspan', 'rowspan', 'headers']),
    TH: new Set(['colspan', 'rowspan', 'headers', 'scope'])
  };

  const SAFE_STYLE_PROPERTIES = new Set([
    'background-color', 'border', 'border-bottom', 'border-collapse', 'border-color',
    'border-left', 'border-radius', 'border-right', 'border-spacing', 'border-style',
    'border-top', 'border-width', 'color', 'font-family', 'font-feature-settings',
    'font-size', 'font-stretch', 'font-style', 'font-variant', 'font-weight', 'height',
    'letter-spacing', 'line-height', 'list-style-position', 'list-style-type', 'margin',
    'margin-bottom', 'margin-left', 'margin-right', 'margin-top', 'max-width', 'min-width',
    'padding', 'padding-bottom', 'padding-left', 'padding-right', 'padding-top',
    'tab-size', 'text-align', 'text-decoration', 'text-decoration-color',
    'text-decoration-line', 'text-decoration-style', 'text-decoration-thickness',
    'text-indent', 'text-transform', 'vertical-align', 'white-space', 'width',
    'word-break', 'word-spacing', 'overflow-wrap'
  ]);

  const COMPUTED_STYLE_PROPERTIES = [
    'color', 'background-color', 'font-family', 'font-size', 'font-weight', 'font-style',
    'font-variant', 'line-height', 'letter-spacing', 'word-spacing', 'text-align',
    'text-decoration-color', 'text-decoration-line', 'text-decoration-style',
    'text-decoration-thickness', 'text-indent', 'text-transform', 'vertical-align',
    'white-space', 'word-break', 'overflow-wrap', 'tab-size', 'list-style-position',
    'list-style-type', 'border-top', 'border-right', 'border-bottom', 'border-left',
    'border-collapse', 'border-spacing', 'padding-top', 'padding-right', 'padding-bottom',
    'padding-left', 'margin-top', 'margin-right', 'margin-bottom', 'margin-left'
  ];

  const BLOCK_TEXT_TAGS = new Set([
    'ADDRESS', 'ARTICLE', 'ASIDE', 'BLOCKQUOTE', 'CAPTION', 'DD', 'DETAILS', 'DIV', 'DL',
    'DT', 'FIGCAPTION', 'FIGURE', 'FOOTER', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6',
    'HEADER', 'HR', 'LI', 'MAIN', 'NAV', 'OL', 'P', 'PRE', 'SECTION', 'TABLE', 'TBODY',
    'TFOOT', 'THEAD', 'TR', 'UL'
  ]);

  const FORBIDDEN_CAPTURE_SELECTOR = [
    'button', 'form', 'input', 'textarea', 'select', 'option', 'iframe', 'canvas',
    'video', 'audio', 'object', 'embed', 'svg', 'math',
    '[contenteditable="plaintext-only"]', 'input[type="password"]'
  ].join(',');

  const icon = (name) => {
    const paths = {
      layers: '<path d="M12 2 3 7l9 5 9-5-9-5Z"/><path d="m3 12 9 5 9-5"/><path d="m3 17 9 5 9-5"/>',
      plus: '<path d="M12 5v14M5 12h14"/>',
      copy: '<rect width="13" height="13" x="9" y="9" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
      close: '<path d="m18 6-12 12M6 6l12 12"/>',
      minimize: '<path d="M5 12h14"/>',
      collapse: '<path d="m6 9 6 6 6-6"/>',
      expand: '<path d="m18 15-6-6-6 6"/>',
      up: '<path d="m18 15-6-6-6 6"/>',
      down: '<path d="m6 9 6 6 6-6"/>',
      trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 15H6L5 6M10 11v6M14 11v6"/>',
      grip: '<circle cx="9" cy="6" r="1"/><circle cx="15" cy="6" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="9" cy="18" r="1"/><circle cx="15" cy="18" r="1"/>',
      check: '<path d="m20 6-11 11-5-5"/>',
      settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/>',
      chevronRight: '<path d="m9 18 6-6-6-6"/>',
      arrowLeft: '<path d="m15 18-6-6 6-6"/><path d="M9 12h10"/>',
      alert: '<path d="M12 9v4M12 17h.01"/><path d="M10.3 2.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 2.9a2 2 0 0 0-3.4 0Z"/>'
    };
    return `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[name] || ''}</svg>`;
  };

  const host = document.createElement('div');
  host.id = 'excerpt-station-extension-root';
  host.style.setProperty('all', 'initial', 'important');
  host.style.setProperty('display', 'none', 'important');
  host.style.setProperty('position', 'fixed', 'important');
  host.style.setProperty('left', '0', 'important');
  host.style.setProperty('top', '0', 'important');
  host.style.setProperty('width', '0', 'important');
  host.style.setProperty('height', '0', 'important');
  host.style.setProperty('z-index', '2147483647', 'important');
  host.style.setProperty('pointer-events', 'auto', 'important');

  const shadow = host.attachShadow({
    mode: globalThis.__EXCERPT_STATION_TEST_MODE__ === true ? 'open' : 'closed'
  });
  shadow.innerHTML = `
    <style>
      :host { all: initial; color-scheme: light dark; }
      *, *::before, *::after { box-sizing: border-box; }
      button, input { font: inherit; }
      button { -webkit-tap-highlight-color: transparent; }

      .es-root {
        --es-panel: #ffffff;
        --es-surface: #f6f7f9;
        --es-surface-hover: #eef1f5;
        --es-text: #1f2329;
        --es-muted: #646a73;
        --es-faint: #8b919a;
        --es-border: #dfe2e7;
        --es-blue: #3370ff;
        --es-blue-soft: #eaf0ff;
        --es-blue-text: #245bdb;
        --es-purple: #7c4dff;
        --es-purple-soft: #f0ebff;
        --es-green: #178c50;
        --es-red: #cf3f44;
        --es-shadow: rgba(21, 29, 43, 0.18);
        position: fixed;
        inset: 0;
        color: var(--es-text);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", sans-serif;
        font-size: 14px;
        line-height: 1.45;
        pointer-events: none;
      }

      @media (prefers-color-scheme: dark) {
        .es-root {
          --es-panel: #23262b;
          --es-surface: #2b2f35;
          --es-surface-hover: #343941;
          --es-text: #f3f4f6;
          --es-muted: #b0b6c0;
          --es-faint: #8f97a3;
          --es-border: #40454e;
          --es-blue: #6d98ff;
          --es-blue-soft: #29385a;
          --es-blue-text: #bfd0ff;
          --es-purple: #ad8aff;
          --es-purple-soft: #3b3158;
          --es-green: #55c98a;
          --es-red: #ff7d82;
          --es-shadow: rgba(0, 0, 0, 0.42);
        }
      }

      .es-panel {
        position: absolute;
        top: 72px;
        right: 24px;
        width: min(360px, calc(100vw - 24px));
        overflow: hidden;
        border: 1px solid var(--es-border);
        border-radius: 14px;
        color: var(--es-text);
        background: var(--es-panel);
        box-shadow: 0 18px 48px var(--es-shadow);
        pointer-events: auto;
      }

      .es-header {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 14px 14px 12px;
        border-bottom: 1px solid var(--es-border);
        cursor: grab;
        user-select: none;
      }

      .es-header:active { cursor: grabbing; }
      .es-title-wrap { flex: 1; min-width: 0; }
      .es-title-line { display: flex; align-items: center; gap: 8px; }
      .es-title-line > svg { width: 18px; height: 18px; color: var(--es-blue); }
      .es-title { margin: 0; font-size: 16px; font-weight: 600; line-height: 1.35; white-space: nowrap; }
      .es-count {
        display: inline-grid;
        min-width: 22px;
        height: 22px;
        padding: 0 6px;
        place-items: center;
        border-radius: 999px;
        color: var(--es-blue-text);
        background: var(--es-blue-soft);
        font-size: 12px;
        font-weight: 600;
      }
      .es-header-actions { display: flex; flex: 0 0 auto; align-items: center; gap: 2px; }

      .es-button {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 7px;
        min-height: 34px;
        padding: 7px 11px;
        border: 1px solid var(--es-border);
        border-radius: 8px;
        color: var(--es-text);
        background: var(--es-panel);
        font-weight: 600;
        cursor: pointer;
      }
      .es-button:hover { background: var(--es-surface-hover); }
      .es-button:focus-visible, .es-checkbox:focus-visible {
        outline: 2px solid var(--es-blue);
        outline-offset: 2px;
      }
      .es-button:disabled { opacity: 0.45; cursor: default; }
      .es-button svg { width: 16px; height: 16px; flex: 0 0 auto; }
      @keyframes es-plus-success {
        0%, 100% { transform: scale(1); filter: none; }
        45% { transform: scale(1.035); filter: brightness(1.06) drop-shadow(0 0 5px rgba(47, 107, 255, 0.28)); }
      }
      .es-success-pulse {
        animation: es-plus-success 340ms cubic-bezier(0.22, 0.78, 0.24, 1);
        transform-origin: center;
      }
      .es-icon-button { width: 32px; min-height: 32px; padding: 6px; border-color: transparent; background: transparent; }
      .es-icon-button.is-active { color: var(--es-blue-text); background: var(--es-blue-soft); }
      .es-primary { border-color: var(--es-blue); color: #ffffff; background: var(--es-blue); }
      .es-primary:hover { filter: brightness(0.96); background: var(--es-blue); }
      .es-ghost { border-color: transparent; color: var(--es-muted); background: transparent; }

      .es-new-wrap { padding: 12px 12px 6px; }
      .es-new { width: 100%; border-style: dashed; color: var(--es-blue-text); background: var(--es-blue-soft); }
      .es-new.is-active { border-style: solid; border-color: var(--es-blue); }

      .es-toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        min-height: 38px;
        padding: 5px 14px 5px 22px;
        color: var(--es-muted);
        font-size: 12px;
      }
      .es-check-label { display: inline-flex; align-items: center; gap: 7px; cursor: pointer; }
      .es-checkbox { width: 16px; height: 16px; margin: 0; accent-color: var(--es-blue); cursor: pointer; }

      .es-list {
        display: grid;
        gap: 9px;
        max-height: min(46vh, 430px);
        overflow: auto;
        padding: 4px 10px 12px;
        overscroll-behavior: contain;
      }
      .es-empty { padding: 22px 14px 26px; color: var(--es-muted); text-align: center; line-height: 1.65; }
      .es-empty strong { display: block; margin-bottom: 4px; color: var(--es-text); font-weight: 600; }

      .es-card { padding: 11px; border: 1px solid var(--es-border); border-radius: 10px; background: var(--es-surface); transition: border-color 120ms ease, box-shadow 120ms ease, opacity 120ms ease; }
      .es-card.is-dragging { z-index: 1; border-color: var(--es-blue); box-shadow: 0 8px 22px var(--es-shadow); opacity: 0.78; }
      .es-card-top { display: flex; align-items: center; gap: 6px; }
      .es-grip { color: var(--es-faint); cursor: grab; touch-action: none; }
      .es-grip:active { cursor: grabbing; }
      .es-grip svg { width: 15px; height: 15px; }
      .es-card-name { flex: 1; min-width: 0; overflow: hidden; font-weight: 600; text-overflow: ellipsis; white-space: nowrap; }
      .es-mini { width: 27px; min-height: 27px; padding: 4px; border-color: transparent; color: var(--es-muted); background: transparent; }
      .es-mini svg { width: 14px; height: 14px; }
      .es-preview { margin: 8px 0 0 23px; color: var(--es-muted); font-size: 12px; line-height: 1.55; overflow-wrap: anywhere; }

      .es-view[hidden] { display: none !important; }
      .es-settings-view, .es-guide-view { padding: 12px; }
      .es-settings-card {
        overflow: hidden;
        border: 1px solid var(--es-border);
        border-radius: 10px;
        background: var(--es-surface);
      }
      .es-settings-row {
        width: 100%;
        min-height: 52px;
        padding: 12px 14px;
        border: 0;
        color: var(--es-text);
        background: transparent;
        text-align: left;
      }
      button.es-settings-row { display: flex; align-items: center; justify-content: space-between; cursor: pointer; }
      button.es-settings-row:hover { background: var(--es-surface-hover); }
      .es-settings-label { font-weight: 600; }
      .es-settings-row > svg { width: 17px; height: 17px; color: var(--es-muted); }
      .es-color-field { padding: 10px 14px 14px; }
      .es-color-title { margin-bottom: 10px; font-weight: 600; }
      .es-color-options { display: flex; flex-wrap: wrap; gap: 8px; }
      .es-color-option {
        position: relative;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        min-height: 32px;
        padding: 5px 8px;
        border: 1px solid var(--es-border);
        border-radius: 8px;
        background: var(--es-panel);
        cursor: pointer;
      }
      .es-color-option:hover { background: var(--es-surface-hover); }
      .es-color-option:has(input:checked) { border-color: var(--es-blue); box-shadow: 0 0 0 1px var(--es-blue); }
      .es-color-option input { position: absolute; width: 1px; height: 1px; opacity: 0; }
      .es-color-option:has(input:focus-visible) { outline: 2px solid var(--es-blue); outline-offset: 2px; }
      .es-color-swatch { width: 17px; height: 17px; border: 1px solid rgba(31, 35, 41, 0.24); border-radius: 5px; background: var(--es-swatch); }
      .es-color-name { color: var(--es-muted); font-size: 12px; }
      .es-floating-field { padding: 2px 14px 14px; }
      .es-floating-title { margin-bottom: 10px; font-weight: 600; }
      .es-floating-options { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; }
      .es-floating-option {
        position: relative;
        display: grid;
        min-height: 34px;
        padding: 6px 10px;
        place-items: center;
        border: 1px solid var(--es-border);
        border-radius: 8px;
        background: var(--es-panel);
        color: var(--es-muted);
        font-size: 12px;
        cursor: pointer;
      }
      .es-floating-option:hover { background: var(--es-surface-hover); }
      .es-floating-option:has(input:checked) { border-color: var(--es-blue); color: var(--es-blue-text); box-shadow: 0 0 0 1px var(--es-blue); }
      .es-floating-option input { position: absolute; width: 1px; height: 1px; opacity: 0; }
      .es-floating-option:has(input:focus-visible) { outline: 2px solid var(--es-blue); outline-offset: 2px; }
      .es-guide-back { margin-bottom: 10px; }
      .es-guide-title { margin: 2px 2px 10px; font-size: 15px; }
      .es-guide-list { margin: 0; padding: 0 0 0 24px; color: var(--es-muted); line-height: 1.7; }
      .es-guide-list li + li { margin-top: 7px; }

      .es-footer { padding: 12px 14px 14px; border-top: 1px solid var(--es-border); }
      .es-footer-actions { display: grid; grid-template-columns: auto minmax(0, 1fr); gap: 8px; }
      .es-delete-selected { color: var(--es-red); }
      .es-copy { width: 100%; }
      .es-copy-status { min-height: 17px; margin: 7px 0 0; color: var(--es-green); font-size: 12px; text-align: center; }
      .es-copy-status.is-error { color: var(--es-red); }

      .es-toast {
        position: absolute;
        right: 24px;
        bottom: 24px;
        display: none;
        align-items: center;
        gap: 10px;
        max-width: min(380px, calc(100vw - 24px));
        padding: 10px 12px;
        border: 1px solid var(--es-border);
        border-radius: 10px;
        color: var(--es-text);
        background: var(--es-panel);
        box-shadow: 0 10px 30px var(--es-shadow);
        pointer-events: auto;
      }
      .es-toast.is-visible { display: flex; }
      .es-toast-text { flex: 1; }
      .es-toast-action { color: var(--es-blue-text); }

      .es-capture-shield {
        position: absolute;
        inset: 0;
        display: none;
        cursor: none;
        pointer-events: auto;
      }
      .es-capture-shield.is-active { display: block; }

      .es-range-layer { position: absolute; inset: 0; pointer-events: none; }
      .es-range-rect {
        position: absolute;
        border-radius: 2px;
        background: var(--es-selection-color);
        opacity: 0.58;
        pointer-events: none;
      }

      .es-marker {
        --es-marker-color: var(--es-blue);
        position: absolute;
        display: none;
        width: 1px;
        height: 1px;
        color: var(--es-marker-color);
        pointer-events: none;
        filter: drop-shadow(0 1px 2px rgba(0, 0, 0, 0.22));
      }
      .es-marker.is-visible { display: block; }
      .es-marker.is-end { --es-marker-color: var(--es-purple); }
      .es-root.has-selection-color .es-marker { --es-marker-color: var(--es-selection-color); }
      .es-caret-line {
        position: absolute;
        left: -1px;
        top: 0;
        width: 3px;
        height: var(--es-caret-size, 20px);
        border-radius: 2px;
        background: var(--es-marker-color);
      }
      .es-marker.is-horizontal-caret .es-caret-line {
        left: 0;
        top: -1px;
        width: var(--es-caret-size, 20px);
        height: 3px;
      }
      .es-mini-stack {
        position: absolute;
        top: 72px;
        right: 24px;
        display: none;
        gap: 8px;
        cursor: grab;
        pointer-events: auto;
        touch-action: none;
        user-select: none;
      }
      .es-mini-stack.is-dragging { cursor: grabbing; }
      .es-mini-stack.is-dragging .es-float-tile { cursor: grabbing; }
      .es-root.is-minimized .es-panel { display: none; }
      .es-root.is-minimized .es-mini-stack { display: grid; }
      .es-root.is-mini-single #es-mini-new { display: none; }
      .es-float-tile {
        position: relative;
        display: grid;
        width: 48px;
        height: 48px;
        padding: 0;
        place-items: center;
        border: 1px solid var(--es-border);
        border-radius: 13px;
        color: var(--es-text);
        background: var(--es-panel);
        box-shadow: 0 10px 28px var(--es-shadow);
        cursor: grab;
      }
      .es-float-tile:hover { background: var(--es-surface-hover); }
      .es-float-tile:focus-visible { outline: 2px solid var(--es-blue); outline-offset: 2px; }
      .es-float-tile svg { width: 21px; height: 21px; }
      .es-float-icon { display: grid; place-items: center; }
      .es-float-primary { color: #ffffff; background: var(--es-blue); border-color: var(--es-blue); }
      .es-float-primary:hover { filter: brightness(0.96); background: var(--es-blue); }
      .es-root.is-mini-single #es-mini-expand { color: #ffffff; background: var(--es-blue); border-color: var(--es-blue); }
      .es-root.is-mini-single #es-mini-expand:hover { filter: brightness(0.96); background: var(--es-blue); }
      .es-mini-count {
        position: absolute;
        top: -6px;
        right: -6px;
        display: grid;
        min-width: 20px;
        height: 20px;
        padding: 0 5px;
        place-items: center;
        border: 2px solid var(--es-panel);
        border-radius: 999px;
        color: #ffffff;
        background: var(--es-purple);
        font-size: 11px;
        font-weight: 700;
        line-height: 1;
      }

      @media (prefers-reduced-motion: reduce) {
        .es-success-pulse { animation: none; filter: brightness(1.04) drop-shadow(0 0 4px rgba(47, 107, 255, 0.22)); }
      }

      @media (max-width: 520px) {
        .es-panel { top: 12px; right: 12px; width: calc(100vw - 24px); }
        .es-mini-stack { top: 12px; right: 12px; }
        .es-list { max-height: 42vh; }
        .es-toast { right: 12px; bottom: 12px; }
      }
    </style>

    <div class="es-root">
      <div class="es-range-layer" id="es-range-layer" aria-hidden="true"></div>
      <div class="es-capture-shield" id="es-capture-shield" aria-hidden="true"></div>
      <div class="es-marker" id="es-start-marker" aria-hidden="true">
        <span class="es-caret-line"></span>
      </div>
      <div class="es-marker is-end" id="es-end-marker" aria-hidden="true">
        <span class="es-caret-line"></span>
      </div>

      <section class="es-panel" id="es-panel" role="dialog" aria-label="摘录中转站">
        <header class="es-header" id="es-drag-handle">
          <div class="es-title-wrap">
            <div class="es-title-line">${icon('layers')}<h2 class="es-title">摘录中转站</h2><span class="es-count" id="es-count">0</span></div>
          </div>
          <div class="es-header-actions">
            <button type="button" class="es-button es-icon-button es-ghost" id="es-settings" aria-label="打开设置" aria-expanded="false">${icon('settings')}</button>
            <button type="button" class="es-button es-icon-button es-ghost" id="es-minimize" aria-label="最小化中转站">${icon('minimize')}</button>
            <button type="button" class="es-button es-icon-button es-ghost" id="es-close" aria-label="退出并清空中转站">${icon('close')}</button>
          </div>
        </header>

        <div class="es-body">
          <div class="es-view" id="es-station-view">
            <div class="es-new-wrap">
              <button type="button" class="es-button es-new" id="es-new">${icon('plus')}<span>新建片段</span></button>
            </div>
            <div class="es-toolbar">
              <label class="es-check-label" for="es-select-all"><input class="es-checkbox" id="es-select-all" type="checkbox"> 全选</label>
              <span id="es-selected-count">已选 0 段</span>
            </div>
            <div class="es-list" id="es-list" aria-live="polite"></div>
            <footer class="es-footer">
              <div class="es-footer-actions">
                <button type="button" class="es-button es-delete-selected" id="es-delete-selected" disabled>${icon('trash')}<span>删除已选中</span></button>
                <button type="button" class="es-button es-primary es-copy" id="es-copy" disabled>${icon('copy')}<span>复制所选（0 段）</span></button>
              </div>
              <p class="es-copy-status" id="es-copy-status" aria-live="polite"></p>
            </footer>
          </div>

          <section class="es-view es-settings-view" id="es-settings-view" aria-label="设置" hidden>
            <div class="es-settings-card">
              <button type="button" class="es-settings-row" id="es-guide-open">
                <span class="es-settings-label">使用指引</span>${icon('chevronRight')}
              </button>
              <div class="es-color-field">
                <div class="es-color-title" id="es-color-title">选中区域颜色设置</div>
                <div class="es-color-options" role="radiogroup" aria-labelledby="es-color-title">
                  <label class="es-color-option"><input type="radio" name="es-highlight-color" value="#A9CAFF"><span class="es-color-swatch" style="--es-swatch:#A9CAFF"></span><span class="es-color-name">蓝色</span></label>
                  <label class="es-color-option"><input type="radio" name="es-highlight-color" value="#FFE46B"><span class="es-color-swatch" style="--es-swatch:#FFE46B"></span><span class="es-color-name">黄色</span></label>
                  <label class="es-color-option"><input type="radio" name="es-highlight-color" value="#FF9FA9"><span class="es-color-swatch" style="--es-swatch:#FF9FA9"></span><span class="es-color-name">红色</span></label>
                  <label class="es-color-option"><input type="radio" name="es-highlight-color" value="#8FE3C0"><span class="es-color-swatch" style="--es-swatch:#8FE3C0"></span><span class="es-color-name">绿色</span></label>
                </div>
              </div>
              <div class="es-floating-field">
                <div class="es-floating-title" id="es-floating-title">悬浮按钮</div>
                <div class="es-floating-options" role="radiogroup" aria-labelledby="es-floating-title">
                  <label class="es-floating-option"><input type="radio" name="es-floating-mode" value="dual"><span>双按钮</span></label>
                  <label class="es-floating-option"><input type="radio" name="es-floating-mode" value="single"><span>单按钮</span></label>
                </div>
              </div>
            </div>
          </section>

          <section class="es-view es-guide-view" id="es-guide-view" aria-label="使用指引" hidden>
            <button type="button" class="es-button es-ghost es-guide-back" id="es-guide-back">${icon('arrowLeft')}<span>返回设置</span></button>
            <h3 class="es-guide-title">使用指引</h3>
            <ol class="es-guide-list">
              <li>点击“新建片段”，把光标放在起始字符上，点击一次确定起点。</li>
              <li>松开触控板并正常滚动页面，再把光标放在结束字符上，点击一次确定终点。</li>
              <li>第二次点击后才会生成片段，并静默自动复制刚完成的片段。</li>
              <li>重复新建可收集多段；勾选片段后可排序、删除，或一次复制所选内容。</li>
              <li>最小化按钮可拖动；双按钮模式下上方展开、下方新建，单按钮模式下左键新建、右键展开。</li>
              <li>“选中区域颜色设置”可改变范围衬色和两端光标颜色；双击不可读取的区域可退出本次选取。</li>
            </ol>
          </section>
        </div>
      </section>

      <div class="es-mini-stack" id="es-mini-stack" aria-label="最小化的摘录中转站">
        <button type="button" class="es-float-tile" id="es-mini-expand" aria-label="展开中转站，当前 0 个片段">
          <span class="es-float-icon" id="es-mini-main-icon">${icon('layers')}</span><span class="es-mini-count" id="es-mini-count">0</span>
        </button>
        <button type="button" class="es-float-tile es-float-primary" id="es-mini-new" aria-label="新建片段">${icon('plus')}</button>
      </div>

      <div class="es-toast" id="es-toast" role="status" aria-live="polite">
        <span class="es-toast-text" id="es-toast-text"></span>
        <button type="button" class="es-button es-ghost es-toast-action" id="es-toast-action"></button>
      </div>
    </div>
  `;

  document.documentElement.appendChild(host);

  const panel = shadow.querySelector('#es-panel');
  const root = shadow.querySelector('.es-root');
  const dragHandle = shadow.querySelector('#es-drag-handle');
  const settingsButton = shadow.querySelector('#es-settings');
  const minimizeButton = shadow.querySelector('#es-minimize');
  const closeButton = shadow.querySelector('#es-close');
  const miniStack = shadow.querySelector('#es-mini-stack');
  const miniExpandButton = shadow.querySelector('#es-mini-expand');
  const miniMainIcon = shadow.querySelector('#es-mini-main-icon');
  const miniNewButton = shadow.querySelector('#es-mini-new');
  const miniCountBadge = shadow.querySelector('#es-mini-count');
  const newButton = shadow.querySelector('#es-new');
  const countBadge = shadow.querySelector('#es-count');
  const selectAll = shadow.querySelector('#es-select-all');
  const selectedCount = shadow.querySelector('#es-selected-count');
  const list = shadow.querySelector('#es-list');
  const deleteSelectedButton = shadow.querySelector('#es-delete-selected');
  const copyButton = shadow.querySelector('#es-copy');
  const copyStatus = shadow.querySelector('#es-copy-status');
  const stationView = shadow.querySelector('#es-station-view');
  const settingsView = shadow.querySelector('#es-settings-view');
  const guideView = shadow.querySelector('#es-guide-view');
  const guideOpenButton = shadow.querySelector('#es-guide-open');
  const guideBackButton = shadow.querySelector('#es-guide-back');
  const colorInputs = Array.from(shadow.querySelectorAll('input[name="es-highlight-color"]'));
  const floatingModeInputs = Array.from(shadow.querySelectorAll('input[name="es-floating-mode"]'));
  const rangeLayer = shadow.querySelector('#es-range-layer');
  const captureShield = shadow.querySelector('#es-capture-shield');
  const startMarker = shadow.querySelector('#es-start-marker');
  const endMarker = shadow.querySelector('#es-end-marker');
  const toast = shadow.querySelector('#es-toast');
  const toastText = shadow.querySelector('#es-toast-text');
  const toastAction = shadow.querySelector('#es-toast-action');

  let visible = false;
  let minimized = false;
  let panelView = 'station';
  let selectionColor = DEFAULT_SELECTION_COLOR;
  let selectionPreferenceTouched = false;
  let floatingMode = DEFAULT_FLOATING_MODE;
  let floatingModePreferenceTouched = false;
  let captureMode = 'idle';
  let startPoint = null;
  let hoverPoint = null;
  let previewPoint = null;
  let hoverUnreadable = false;
  let lastPointer = null;
  let suppressGestureUntil = 0;
  let shieldReleaseTimer = 0;
  let shieldReleasePending = false;
  let markerFrame = 0;
  let markerRepickPending = false;
  let capturePress = null;
  let toastTimer = 0;
  let toastCallback = null;
  let successPulseTimer = 0;
  let nextSegmentId = 1;
  let segments = [];
  let cardDrag = null;
  let manualCopyPending = false;
  let clipboardQueue = Promise.resolve();
  let stationRevision = 0;

  const segmenter = typeof Intl.Segmenter === 'function'
    ? new Intl.Segmenter(undefined, { granularity: 'grapheme' })
    : null;

  const api = {
    toggle() {
      setVisible(!visible);
    },
    show() {
      setVisible(true);
    },
    hide() {
      setVisible(false);
    },
    getState() {
      return {
        visible,
        minimized,
        panelView,
        selectionColor,
        floatingMode,
        captureMode,
        segmentCount: segments.length,
        segmentIds: segments.map((segment) => segment.id)
      };
    }
  };

  globalThis.__EXCERPT_STATION_MVP__ = api;

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type !== 'EXCERPT_STATION_TOGGLE') return false;
    api.toggle();
    sendResponse?.({ ok: true, visible });
    return false;
  });

  function setVisible(nextVisible) {
    visible = nextVisible;
    host.style.setProperty('display', visible ? 'block' : 'none', 'important');
    if (!visible) cancelCapture();
    render();
  }

  function normalizeSelectionColor(value) {
    return typeof value === 'string' && SELECTION_COLORS.has(value) ? value : DEFAULT_SELECTION_COLOR;
  }

  function applySelectionColor(value, { persist = false } = {}) {
    selectionColor = normalizeSelectionColor(value);
    if (persist) {
      selectionPreferenceTouched = true;
      persistSelectionColor(selectionColor);
    }
    render();
    updateSelectionPreview();
  }

  function persistSelectionColor(value) {
    try {
      const pendingWrite = chrome.storage?.local?.set?.({ [SELECTION_COLOR_STORAGE_KEY]: value });
      if (pendingWrite?.catch) void pendingWrite.catch(() => {});
    } catch (error) {
      // The visual preference still works for this page when storage is unavailable.
    }
  }

  async function loadSelectionColorPreference() {
    try {
      const stored = await chrome.storage?.local?.get?.(SELECTION_COLOR_STORAGE_KEY);
      if (!selectionPreferenceTouched) {
        const storedValue = stored?.[SELECTION_COLOR_STORAGE_KEY];
        const normalizedValue = normalizeSelectionColor(storedValue);
        applySelectionColor(normalizedValue);
        if (storedValue !== normalizedValue) persistSelectionColor(normalizedValue);
      }
    } catch (error) {
      // Keep the default blue preference if browser storage cannot be read.
    }
  }

  function normalizeFloatingMode(value) {
    return typeof value === 'string' && FLOATING_MODES.has(value) ? value : DEFAULT_FLOATING_MODE;
  }

  function applyFloatingMode(value, { persist = false } = {}) {
    floatingMode = normalizeFloatingMode(value);
    if (persist) {
      floatingModePreferenceTouched = true;
      persistFloatingMode(floatingMode);
    }
    render();
    if (minimized) requestAnimationFrame(clampMiniStackToViewport);
  }

  function persistFloatingMode(value) {
    try {
      const pendingWrite = chrome.storage?.local?.set?.({ [FLOATING_MODE_STORAGE_KEY]: value });
      if (pendingWrite?.catch) void pendingWrite.catch(() => {});
    } catch (error) {
      // The floating preference still works for this page when storage is unavailable.
    }
  }

  async function loadFloatingModePreference() {
    try {
      const stored = await chrome.storage?.local?.get?.(FLOATING_MODE_STORAGE_KEY);
      if (!floatingModePreferenceTouched) {
        const storedValue = stored?.[FLOATING_MODE_STORAGE_KEY];
        const normalizedValue = normalizeFloatingMode(storedValue);
        applyFloatingMode(normalizedValue);
        if (storedValue !== normalizedValue) persistFloatingMode(normalizedValue);
      }
    } catch (error) {
      // Keep the default dual-button preference if browser storage cannot be read.
    }
  }

  function render() {
    countBadge.textContent = String(segments.length);
    miniCountBadge.textContent = String(segments.length);
    const isSingleFloatingMode = floatingMode === 'single';
    miniMainIcon.innerHTML = isSingleFloatingMode
      ? (captureMode === 'idle' ? icon('plus') : icon('close'))
      : icon('layers');
    miniExpandButton.setAttribute(
      'aria-label',
      isSingleFloatingMode
        ? `${captureMode === 'idle' ? '左键新建片段' : '左键取消本次选取'}，右键展开中转站，当前 ${segments.length} 个片段`
        : `展开中转站，当前 ${segments.length} 个片段`
    );
    const checkedCount = segments.filter((segment) => segment.selected).length;
    selectedCount.textContent = `已选 ${checkedCount} 段`;
    selectAll.checked = segments.length > 0 && checkedCount === segments.length;
    selectAll.indeterminate = checkedCount > 0 && checkedCount < segments.length;
    deleteSelectedButton.disabled = checkedCount === 0;
    copyButton.disabled = checkedCount === 0 || manualCopyPending;
    copyButton.querySelector('span').textContent = `复制所选（${checkedCount} 段）`;
    root.classList.toggle('is-minimized', minimized);
    root.classList.toggle('is-mini-single', isSingleFloatingMode);
    root.classList.add('has-selection-color');
    root.style.setProperty('--es-selection-color', selectionColor);
    stationView.hidden = panelView !== 'station';
    settingsView.hidden = panelView !== 'settings';
    guideView.hidden = panelView !== 'guide';
    settingsButton.classList.toggle('is-active', panelView !== 'station');
    settingsButton.setAttribute('aria-expanded', String(panelView !== 'station'));
    settingsButton.setAttribute('aria-label', panelView === 'station' ? '打开设置' : '返回摘录中转站');
    settingsButton.innerHTML = panelView === 'station' ? icon('settings') : icon('arrowLeft');
    colorInputs.forEach((input) => { input.checked = input.value === selectionColor; });
    floatingModeInputs.forEach((input) => { input.checked = input.value === floatingMode; });
    miniNewButton.innerHTML = captureMode === 'idle' ? icon('plus') : icon('close');
    miniNewButton.setAttribute('aria-label', captureMode === 'idle' ? '新建片段' : '取消本次选取');

    if (captureMode === 'idle') {
      newButton.classList.remove('is-active');
      newButton.innerHTML = `${icon('plus')}<span>新建片段</span>`;
    } else {
      newButton.classList.add('is-active');
      newButton.innerHTML = `${icon('close')}<span>取消本次选取</span>`;
    }

    renderSegments();
  }

  function renderSegments() {
    list.replaceChildren();

    if (!segments.length) {
      const empty = document.createElement('div');
      empty.className = 'es-empty';
      const strong = document.createElement('strong');
      strong.textContent = '中转站还是空的';
      empty.appendChild(strong);
      list.appendChild(empty);
      return;
    }

    segments.forEach((segment, index) => {
      const card = document.createElement('article');
      card.className = 'es-card';
      card.dataset.segmentId = String(segment.id);

      const top = document.createElement('div');
      top.className = 'es-card-top';

      const checkbox = document.createElement('input');
      checkbox.className = 'es-checkbox';
      checkbox.type = 'checkbox';
      checkbox.checked = segment.selected;
      checkbox.dataset.action = 'select';
      checkbox.setAttribute('aria-label', `选择片段 ${index + 1}`);

      const name = document.createElement('span');
      name.className = 'es-card-name';
      name.textContent = `片段${index + 1}：${segment.sourceTitle}`;
      name.title = name.textContent;

      const grip = makeMiniButton('drag', 'grip', `拖拽移动第 ${index + 1} 条内容`, false);
      grip.classList.add('es-grip');
      const remove = makeMiniButton('delete', 'trash', `删除片段 ${index + 1}`, false);
      top.append(checkbox, name, grip, remove);

      const preview = document.createElement('p');
      preview.className = 'es-preview';
      preview.textContent = segment.previewText;

      card.append(top, preview);
      list.appendChild(card);
    });
  }

  function makeMiniButton(action, iconName, label, disabled) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'es-button es-mini';
    button.dataset.action = action;
    button.setAttribute('aria-label', label);
    button.disabled = disabled;
    button.innerHTML = icon(iconName);
    return button;
  }

  function beginCapture() {
    if (segments.length >= MAX_SEGMENTS) {
      showToast(`最多暂存 ${MAX_SEGMENTS} 个片段，请先删除一部分。`);
      return;
    }

    panelView = 'station';
    clearSuccessPulse();
    captureMode = 'start';
    startPoint = null;
    hoverPoint = null;
    previewPoint = null;
    setHoverUnreadable(false);
    capturePress = null;
    copyStatus.textContent = '';
    document.documentElement.classList.add(CAPTURE_CLASS);
    enableCaptureShield();
    render();
    scheduleMarkerUpdate(true);
  }

  function cancelCapture(message = '') {
    captureMode = 'idle';
    startPoint = null;
    hoverPoint = null;
    previewPoint = null;
    setHoverUnreadable(false);
    capturePress = null;
    document.documentElement.classList.remove(CAPTURE_CLASS);
    disableCaptureShield();
    hideAllMarkers();
    if (message) showToast(message);
    render();
  }

  function finishCapture(range) {
    const segment = snapshotRange(range);
    const nextBytes = totalStoredBytes() + segment.byteSize;

    if (nextBytes > MAX_TOTAL_BYTES) {
      throw new Error('中转站内容已超过 8 MB，请先复制或删除部分片段。');
    }

    segments.push(segment);
    const revision = stationRevision;
    captureMode = 'idle';
    startPoint = null;
    hoverPoint = null;
    previewPoint = null;
    setHoverUnreadable(false);
    document.documentElement.classList.remove(CAPTURE_CLASS);
    releaseCaptureShieldAfterGesture();
    render();
    void enqueueClipboardWrite([segment])
      .then(() => {
        if (revision !== stationRevision || captureMode !== 'idle') return;
        pulseNewSegmentSuccess();
      })
      .catch((error) => {
        if (revision !== stationRevision) return;
        showToast(`片段已保存，但自动复制失败：${error?.message || '未知错误'}`);
      });

    hideAllMarkers();
  }

  function exitCaptureAfterGesture() {
    captureMode = 'idle';
    startPoint = null;
    hoverPoint = null;
    previewPoint = null;
    capturePress = null;
    hoverUnreadable = false;
    document.documentElement.classList.remove(CAPTURE_CLASS);
    disableCaptureShield();
    hideAllMarkers();
    render();
  }

  function setHoverUnreadable(nextUnreadable) {
    hoverUnreadable = Boolean(nextUnreadable) && captureMode !== 'idle';
  }

  function handlePointerMove(event, fromShield = false) {
    if (!isTrustedInteraction(event) || captureMode === 'idle' || (!fromShield && isUiEvent(event))) return;
    lastPointer = { x: event.clientX, y: event.clientY };
    if (capturePress && capturePress.pointerId === event.pointerId) {
      capturePress.maxDistance = Math.max(
        capturePress.maxDistance,
        Math.hypot(event.clientX - capturePress.x, event.clientY - capturePress.y)
      );
    }
    scheduleMarkerUpdate(true);
  }

  function handleCapturePointerDown(event, fromShield = false) {
    if (!isTrustedInteraction(event) || captureMode === 'idle' || (!fromShield && isUiEvent(event)) || event.button !== 0) return;

    blockPageEvent(event);
    suppressGestureUntil = performance.now() + 650;
    lastPointer = { x: event.clientX, y: event.clientY };
    capturePress = {
      pointerId: event.pointerId,
      x: event.clientX,
      y: event.clientY,
      maxDistance: 0
    };
    if (fromShield) {
      try {
        captureShield.setPointerCapture(event.pointerId);
      } catch (error) {
        // Pointer capture is an enhancement; click confirmation still works without it.
      }
    }
    scheduleMarkerUpdate(true);
  }

  function handleCapturePointerUp(event, fromShield = false) {
    if (!isTrustedInteraction(event) || captureMode === 'idle' || (!fromShield && isUiEvent(event))) return;
    if (!capturePress || capturePress.pointerId !== event.pointerId) return;

    blockPageEvent(event);
    const press = capturePress;
    capturePress = null;
    if (fromShield) {
      try {
        captureShield.releasePointerCapture(event.pointerId);
      } catch (error) {
        // Pointer capture may already have ended.
      }
    }

    lastPointer = { x: event.clientX, y: event.clientY };
    const distance = Math.hypot(event.clientX - press.x, event.clientY - press.y);
    if (Math.max(distance, press.maxDistance) > CAPTURE_CLICK_SLOP) {
      scheduleMarkerUpdate(true);
      return;
    }
    suppressGestureUntil = performance.now() + 650;
    commitCapturePoint(event.clientX, event.clientY);
  }

  function handleCapturePointerCancel(event, fromShield = false) {
    if (!fromShield && isUiEvent(event)) return;
    if (!capturePress || capturePress.pointerId !== event.pointerId) return;
    if (isTrustedInteraction(event)) blockPageEvent(event);
    capturePress = null;
    if (fromShield) {
      try {
        captureShield.releasePointerCapture(event.pointerId);
      } catch (error) {
        // Pointer capture may already have ended.
      }
    }
  }

  function commitCapturePoint(x, y) {
    const role = captureMode === 'start' ? 'start' : 'end';
    const result = pickPoint(x, y, role);
    if (result.unreadable) {
      hoverPoint = null;
      setHoverUnreadable(true);
      updateMarkers();
      updateSelectionPreview();
      return;
    }
    if (!result.point) {
      scheduleMarkerUpdate(true);
      return;
    }

    if (captureMode === 'start') {
      startPoint = result.point;
      captureMode = 'end';
      hoverPoint = null;
      previewPoint = null;
      setHoverUnreadable(false);
      render();
      scheduleMarkerUpdate(true);
      return;
    }

    if (!pointIsStable(startPoint)) {
      cancelCapture('页面内容已经变化，原起点失效，请重新选择。');
      return;
    }

    try {
      const { range } = orderedRange(startPoint, result.point);
      if (range.collapsed) throw new Error('起点和终点重合，请选择至少一个字符。');
      finishCapture(range);
    } catch (error) {
      showToast(error?.message || '无法建立这个选区，请重试。');
    }
  }

  function handleFollowupPageEvent(event) {
    if (!isTrustedInteraction(event) || isUiEvent(event)) return;
    if (captureMode !== 'idle' || performance.now() < suppressGestureUntil) {
      blockPageEvent(event);
    }
  }

  function handleKeyDown(event) {
    if (!isTrustedInteraction(event) || captureMode === 'idle') return;
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopImmediatePropagation();
      cancelCapture();
    }
  }

  function blockPageEvent(event) {
    event.preventDefault();
    event.stopImmediatePropagation();
  }

  function enableCaptureShield() {
    window.clearTimeout(shieldReleaseTimer);
    shieldReleasePending = false;
    captureShield.classList.add('is-active');
  }

  function disableCaptureShield() {
    window.clearTimeout(shieldReleaseTimer);
    shieldReleasePending = false;
    captureShield.classList.remove('is-active');
    hoverUnreadable = false;
  }

  function releaseCaptureShieldAfterGesture() {
    shieldReleasePending = true;
    window.clearTimeout(shieldReleaseTimer);
    shieldReleaseTimer = window.setTimeout(disableCaptureShield, 700);
  }

  function handleShieldFollowupEvent(event) {
    if (!isTrustedInteraction(event)) return;
    const shouldExitUnreadable = event.type === 'dblclick'
      && captureMode !== 'idle'
      && Boolean(pickPoint(event.clientX, event.clientY, captureMode === 'start' ? 'start' : 'end').unreadable);
    blockPageEvent(event);
    if (shouldExitUnreadable) {
      exitCaptureAfterGesture();
      return;
    }
    if (event.type === 'click' && shieldReleasePending) disableCaptureShield();
  }

  function handleShieldWheel(event) {
    if (!isTrustedInteraction(event) || event.ctrlKey) return;
    event.preventDefault();
    event.stopImmediatePropagation();

    const scale = event.deltaMode === WheelEvent.DOM_DELTA_LINE
      ? 16
      : (event.deltaMode === WheelEvent.DOM_DELTA_PAGE ? window.innerHeight : 1);
    const deltaX = event.deltaX * scale;
    const deltaY = event.deltaY * scale;
    const previousPointerEvents = captureShield.style.pointerEvents;
    captureShield.style.pointerEvents = 'none';
    const underlying = document.elementFromPoint(event.clientX, event.clientY);
    captureShield.style.pointerEvents = previousPointerEvents;

    const scrollContainer = findScrollableContainer(underlying, deltaX, deltaY);
    if (scrollContainer) scrollContainer.scrollBy({ left: deltaX, top: deltaY, behavior: 'auto' });
    else window.scrollBy({ left: deltaX, top: deltaY, behavior: 'auto' });
    scheduleMarkerUpdate(true);
  }

  function findScrollableContainer(startElement, deltaX, deltaY) {
    for (let current = startElement; current && current !== document.documentElement; current = current.parentElement) {
      if (!(current instanceof Element)) continue;
      const style = getComputedStyle(current);
      const canScrollY = /(auto|scroll|overlay)/.test(style.overflowY)
        && current.scrollHeight > current.clientHeight + 1
        && (deltaY < 0 ? current.scrollTop > 0 : current.scrollTop + current.clientHeight < current.scrollHeight - 1);
      const canScrollX = /(auto|scroll|overlay)/.test(style.overflowX)
        && current.scrollWidth > current.clientWidth + 1
        && (deltaX < 0 ? current.scrollLeft > 0 : current.scrollLeft + current.clientWidth < current.scrollWidth - 1);
      if ((deltaY && canScrollY) || (deltaX && canScrollX)) return current;
    }
    return null;
  }

  function isUiEvent(event) {
    return event.composedPath().includes(host);
  }

  function scheduleMarkerUpdate(repickHover = false) {
    markerRepickPending = markerRepickPending || repickHover;
    if (markerFrame) return;
    markerFrame = requestAnimationFrame(() => {
      markerFrame = 0;
      const shouldRepick = markerRepickPending;
      markerRepickPending = false;
      if (captureMode === 'idle') {
        hideAllMarkers();
        return;
      }

      if (captureMode === 'end' && startPoint && !pointIsStable(startPoint)) {
        cancelCapture('页面内容已经变化，原起点失效，请重新选择。');
        return;
      }

      if (shouldRepick && lastPointer) {
        const role = captureMode === 'start' ? 'start' : 'end';
        const result = pickPoint(lastPointer.x, lastPointer.y, role);
        hoverPoint = result.point || null;
        if (captureMode === 'end' && result.point) previewPoint = result.point;
        setHoverUnreadable(Boolean(result.unreadable));
      }

      updateMarkers();
      updateSelectionPreview();
    });
  }

  function updateMarkers() {
    startMarker.classList.remove('is-visible');
    endMarker.classList.remove('is-visible');

    if (captureMode === 'start') {
      if (hoverPoint) positionMarker(startMarker, hoverPoint, 'start');
      else if (hoverUnreadable && lastPointer) positionMarkerAtPointer(startMarker, lastPointer);
      return;
    }

    if (captureMode === 'end') {
      if (startPoint) positionMarker(startMarker, startPoint, 'start');
      if (hoverPoint) positionMarker(endMarker, hoverPoint, 'end');
      else if (hoverUnreadable && lastPointer) positionMarkerAtPointer(endMarker, lastPointer);
    }
  }

  function updateSelectionPreview() {
    rangeLayer.replaceChildren();
    clearSelectionHighlight();
    if (captureMode !== 'end'
      || !startPoint
      || !previewPoint) return;

    try {
      const { range } = orderedRange(startPoint, previewPoint);
      if (range.collapsed) return;
      const highlightName = SELECTION_HIGHLIGHT_NAMES[selectionColor];
      if (highlightName && globalThis.CSS?.highlights && typeof globalThis.Highlight === 'function') {
        globalThis.CSS.highlights.set(highlightName, new globalThis.Highlight(range));
        return;
      }

      const fragment = document.createDocumentFragment();
      let rendered = 0;
      for (const rect of Array.from(range.getClientRects())) {
        if (rendered >= 600) break;
        if (rect.width <= 0.1 || rect.height <= 0.1) continue;
        const left = Math.max(0, rect.left);
        const top = Math.max(0, rect.top);
        const right = Math.min(window.innerWidth, rect.right);
        const bottom = Math.min(window.innerHeight, rect.bottom);
        if (right <= left || bottom <= top) continue;
        const highlight = document.createElement('span');
        highlight.className = 'es-range-rect';
        highlight.style.left = `${left}px`;
        highlight.style.top = `${top}px`;
        highlight.style.width = `${right - left}px`;
        highlight.style.height = `${bottom - top}px`;
        fragment.appendChild(highlight);
        rendered += 1;
      }
      rangeLayer.appendChild(fragment);
    } catch (error) {
      rangeLayer.replaceChildren();
    }
  }

  function clearSelectionHighlight() {
    if (!globalThis.CSS?.highlights) return;
    Object.values(SELECTION_HIGHLIGHT_NAMES).forEach((name) => {
      globalThis.CSS.highlights.delete(name);
    });
  }

  function positionMarker(marker, point, role) {
    const geometry = resolvePointGeometry(point, role);
    if (!geometry) return;

    positionMarkerGeometry(marker, geometry);
  }

  function positionMarkerAtPointer(marker, pointer) {
    const caretSize = 20;
    const x = Math.min(Math.max(4, pointer.x), Math.max(4, window.innerWidth - 4));
    const y = Math.min(
      Math.max(9, pointer.y - caretSize / 2),
      Math.max(9, window.innerHeight - caretSize - 4)
    );
    positionMarkerGeometry(marker, {
      x,
      y,
      caretSize,
      caretOrientation: 'vertical'
    });
  }

  function positionMarkerGeometry(marker, geometry) {

    const margin = 4;
    const isOutside = geometry.x < -margin || geometry.y < -margin
      || geometry.x > window.innerWidth + margin || geometry.y > window.innerHeight + margin;
    if (isOutside) return;

    marker.style.left = `${geometry.x}px`;
    marker.style.top = `${geometry.y}px`;
    marker.style.setProperty('--es-caret-size', `${Math.max(12, geometry.caretSize)}px`);
    marker.classList.toggle('is-horizontal-caret', geometry.caretOrientation === 'horizontal');
    marker.classList.add('is-visible');
  }

  function hideAllMarkers() {
    startMarker.classList.remove('is-visible');
    endMarker.classList.remove('is-visible');
    rangeLayer.replaceChildren();
    clearSelectionHighlight();
  }

  function pickPoint(x, y, role) {
    const shieldIsActive = captureShield.classList.contains('is-active');
    const previousPointerEvents = captureShield.style.pointerEvents;
    if (shieldIsActive) captureShield.style.pointerEvents = 'none';
    try {
      return pickPointFromPage(x, y, role);
    } finally {
      if (shieldIsActive) captureShield.style.pointerEvents = previousPointerEvents;
    }
  }

  function pickPointFromPage(x, y, role) {
    const target = document.elementFromPoint(x, y);
    if (!target || target === host || host.contains(target)) return { silent: true };

    const forbidden = target.closest?.(FORBIDDEN_CAPTURE_SELECTOR);
    if (forbidden) {
      return { unreadable: true };
    }

    const atomic = target.closest?.('img,hr');
    if (atomic && atomic.parentNode) {
      const point = pointForAtomicElement(atomic, role, x, y);
      return resolvePointGeometry(point, role)
        ? { point }
        : { unreadable: true };
    }

    const raw = rawCaretPoint(x, y);
    if (!raw?.node || !raw.node.isConnected) {
      return { unreadable: true };
    }

    if (raw.node.nodeType === Node.TEXT_NODE) {
      const point = pointForTextGrapheme(raw.node, raw.offset, role, x, y);
      if (point && resolvePointGeometry(point, role)) return { point };
    }

    const point = pointForDomBoundary(raw.node, raw.offset, role, x, y);
    const geometry = point && resolvePointGeometry(point, role);
    return point && geometry && geometryIsNearPointer(geometry, x, y)
      ? { point }
      : { unreadable: true };
  }

  function geometryIsNearPointer(geometry, x, y) {
    const rect = geometry.caretOrientation === 'horizontal'
      ? {
          left: geometry.x,
          right: geometry.x + geometry.caretSize,
          top: geometry.y,
          bottom: geometry.y
        }
      : {
          left: geometry.x,
          right: geometry.x,
          top: geometry.y,
          bottom: geometry.y + geometry.caretSize
        };
    return distanceToRect(x, y, rect) <= CARET_MAX_HIT_DISTANCE * CARET_MAX_HIT_DISTANCE;
  }

  function rawCaretPoint(x, y) {
    if (typeof document.caretPositionFromPoint === 'function') {
      const position = document.caretPositionFromPoint(x, y);
      if (position) return { node: position.offsetNode, offset: position.offset };
    }

    if (typeof document.caretRangeFromPoint === 'function') {
      const range = document.caretRangeFromPoint(x, y);
      if (range) return { node: range.startContainer, offset: range.startOffset };
    }

    return null;
  }

  function pointForTextGrapheme(node, rawOffset, role, x, y) {
    const graphemes = segmentGraphemes(node.data);
    if (!graphemes.length) return null;

    let centerIndex = graphemes.findIndex((item) => rawOffset >= item.start && rawOffset <= item.end);
    if (centerIndex < 0) centerIndex = rawOffset <= 0 ? 0 : graphemes.length - 1;

    const candidateIndexes = new Set([
      Math.max(0, centerIndex - 1),
      centerIndex,
      Math.min(graphemes.length - 1, centerIndex + 1)
    ]);

    let best = null;
    candidateIndexes.forEach((index) => {
      const grapheme = graphemes[index];
      const range = document.createRange();
      range.setStart(node, grapheme.start);
      range.setEnd(node, grapheme.end);
      Array.from(range.getClientRects()).forEach((rect, rectIndex) => {
        if (!rect.width && !rect.height) return;
        const score = distanceToRect(x, y, rect);
        const preferredBoundary = role === 'start'
          ? grapheme.start === rawOffset
          : grapheme.end === rawOffset;
        const preference = preferredBoundary ? 0 : 1;
        if (!best || score < best.score || (score === best.score && preference < best.preference)) {
          best = { grapheme, rectIndex, score, preference };
        }
      });
    });

    if (!best || best.score > CARET_MAX_HIT_DISTANCE * CARET_MAX_HIT_DISTANCE) return null;
    const flow = textFlow(node.parentElement);
    return {
      node,
      offset: role === 'start' ? best.grapheme.start : best.grapheme.end,
      graphemeStart: best.grapheme.start,
      graphemeEnd: best.grapheme.end,
      rectIndex: best.rectIndex,
      direction: flow.direction,
      writingMode: flow.writingMode,
      graphemeText: node.data.slice(best.grapheme.start, best.grapheme.end),
      contextBefore: node.data.slice(Math.max(0, best.grapheme.start - 16), best.grapheme.start),
      contextAfter: node.data.slice(best.grapheme.end, best.grapheme.end + 16),
      role
    };
  }

  function segmentGraphemes(text) {
    if (segmenter) {
      return Array.from(segmenter.segment(text), (entry) => ({
        start: entry.index,
        end: entry.index + entry.segment.length
      }));
    }

    const items = [];
    let offset = 0;
    for (const character of Array.from(text)) {
      items.push({ start: offset, end: offset + character.length });
      offset += character.length;
    }
    return items;
  }

  function distanceToRect(x, y, rect) {
    const dx = x < rect.left ? rect.left - x : (x > rect.right ? x - rect.right : 0);
    const dy = y < rect.top ? rect.top - y : (y > rect.bottom ? y - rect.bottom : 0);
    return dx * dx + dy * dy;
  }

  function pointForAtomicElement(element, role, x, y) {
    const parent = element.parentNode;
    const index = Array.prototype.indexOf.call(parent.childNodes, element);
    const flow = textFlow(element);
    return {
      node: parent,
      offset: role === 'start' ? index : index + 1,
      atomicElement: element,
      atomicParent: parent,
      atomicSignature: `${element.tagName}|${element.getAttribute('src') || ''}|${element.getAttribute('alt') || ''}`,
      direction: flow.direction,
      writingMode: flow.writingMode,
      role,
      hintX: x,
      hintY: y
    };
  }

  function pointForDomBoundary(node, offset, role, x, y) {
    if (node.nodeType !== Node.ELEMENT_NODE && node.nodeType !== Node.DOCUMENT_NODE) return null;
    const element = node.nodeType === Node.ELEMENT_NODE ? node : document.documentElement;
    const maxOffset = node.childNodes?.length ?? 0;
    const flow = textFlow(element);
    return {
      node,
      offset: Math.max(0, Math.min(offset, maxOffset)),
      direction: flow.direction,
      writingMode: flow.writingMode,
      role,
      boundaryBefore: node.childNodes?.[Math.max(0, Math.min(offset, maxOffset)) - 1] || null,
      boundaryAfter: node.childNodes?.[Math.max(0, Math.min(offset, maxOffset))] || null,
      hintX: x,
      hintY: y
    };
  }

  function textFlow(element) {
    const target = element instanceof Element ? element : document.documentElement;
    const computed = getComputedStyle(target);
    return {
      direction: computed.direction === 'rtl' ? 'rtl' : 'ltr',
      writingMode: computed.writingMode || 'horizontal-tb'
    };
  }

  function pointIsStable(point) {
    if (!point?.node?.isConnected) return false;

    if (point.node.nodeType === Node.TEXT_NODE && Number.isInteger(point.graphemeStart)) {
      if (point.graphemeEnd > point.node.length) return false;
      return point.node.data.slice(point.graphemeStart, point.graphemeEnd) === point.graphemeText
        && point.node.data.slice(Math.max(0, point.graphemeStart - 16), point.graphemeStart) === point.contextBefore
        && point.node.data.slice(point.graphemeEnd, point.graphemeEnd + 16) === point.contextAfter;
    }

    if (point.atomicElement) {
      if (!point.atomicElement.isConnected || point.atomicElement.parentNode !== point.atomicParent) return false;
      const signature = `${point.atomicElement.tagName}|${point.atomicElement.getAttribute('src') || ''}|${point.atomicElement.getAttribute('alt') || ''}`;
      return signature === point.atomicSignature;
    }

    if (point.node.childNodes) {
      const before = point.node.childNodes[point.offset - 1] || null;
      const after = point.node.childNodes[point.offset] || null;
      return before === point.boundaryBefore && after === point.boundaryAfter;
    }

    return true;
  }

  function resolvePointGeometry(point, role) {
    if (!point?.node?.isConnected) return null;

    let rect;
    if (point.atomicElement?.isConnected) {
      rect = point.atomicElement.getBoundingClientRect();
    } else if (point.node.nodeType === Node.TEXT_NODE && Number.isInteger(point.graphemeStart)) {
      const range = document.createRange();
      try {
        range.setStart(point.node, point.graphemeStart);
        range.setEnd(point.node, point.graphemeEnd);
      } catch (error) {
        return null;
      }
      const rects = Array.from(range.getClientRects());
      rect = rects[point.rectIndex] || rects[0];
    } else {
      rect = boundaryRect(point);
    }

    if (!rect) return null;
    const verticalWriting = point.writingMode?.startsWith('vertical');
    const isRtl = point.direction === 'rtl';

    if (verticalWriting) {
      const y = role === 'start'
        ? (isRtl ? rect.bottom : rect.top)
        : (isRtl ? rect.top : rect.bottom);
      return {
        x: rect.left,
        y,
        caretSize: Math.max(12, rect.width),
        caretOrientation: 'horizontal'
      };
    }

    const x = role === 'start'
      ? (isRtl ? rect.right : rect.left)
      : (isRtl ? rect.left : rect.right);
    return {
      x,
      y: rect.top,
      caretSize: Math.max(12, rect.height),
      caretOrientation: 'vertical'
    };
  }

  function boundaryRect(point) {
    const range = document.createRange();
    try {
      range.setStart(point.node, point.offset);
      range.collapse(true);
    } catch (error) {
      return null;
    }

    const collapsed = range.getBoundingClientRect();
    if (collapsed && collapsed.height > 0) return collapsed;

    if (point.node.nodeType === Node.TEXT_NODE) {
      if (point.offset < point.node.length) {
        range.setEnd(point.node, point.offset + 1);
        const rect = range.getClientRects()[0];
        if (rect) return { left: rect.left, right: rect.left, top: rect.top, bottom: rect.bottom, width: 0, height: rect.height };
      }
      if (point.offset > 0) {
        range.setStart(point.node, point.offset - 1);
        const rects = range.getClientRects();
        const rect = rects[rects.length - 1];
        if (rect) return { left: rect.right, right: rect.right, top: rect.top, bottom: rect.bottom, width: 0, height: rect.height };
      }
    }

    return null;
  }

  function orderedRange(firstPoint, secondPoint) {
    const reversed = selectionIsReversed(firstPoint, secondPoint);
    const start = boundaryForRange(reversed ? secondPoint : firstPoint, 'start');
    const end = boundaryForRange(reversed ? firstPoint : secondPoint, 'end');
    const range = document.createRange();
    range.setStart(start.node, start.offset);
    range.setEnd(end.node, end.offset);
    return { range, reversed };
  }

  function selectionIsReversed(firstPoint, secondPoint) {
    const firstBoundary = boundaryForRange(firstPoint, 'start');
    const secondBoundary = boundaryForRange(secondPoint, 'start');
    const first = document.createRange();
    const second = document.createRange();
    first.setStart(firstBoundary.node, firstBoundary.offset);
    first.collapse(true);
    second.setStart(secondBoundary.node, secondBoundary.offset);
    second.collapse(true);
    return first.compareBoundaryPoints(Range.START_TO_START, second) > 0;
  }

  function boundaryForRange(point, edge) {
    if (point.node.nodeType === Node.TEXT_NODE && Number.isInteger(point.graphemeStart)) {
      return {
        node: point.node,
        offset: edge === 'start' ? point.graphemeStart : point.graphemeEnd
      };
    }

    if (point.atomicElement?.isConnected && point.atomicElement.parentNode) {
      const parent = point.atomicElement.parentNode;
      const index = Array.prototype.indexOf.call(parent.childNodes, point.atomicElement);
      return { node: parent, offset: edge === 'start' ? index : index + 1 };
    }

    return { node: point.node, offset: point.offset };
  }

  function cloneVisibleRange(range) {
    const fragment = document.createDocumentFragment();
    const common = range.commonAncestorContainer;

    if (common.nodeType === Node.TEXT_NODE) {
      const clone = cloneSelectedNode(common, range);
      if (clone) {
        const parent = common.parentElement;
        if (parent
          && ALLOWED_TAGS.has(parent.tagName)
          && !BLOCKED_TAGS.has(parent.tagName)
          && sourceElementIsVisible(parent)
          && elementHasPotentialVisibleArea(parent)) {
          const shell = createSafeElementShell(parent, document.baseURI);
          if (shell) {
            shell.appendChild(clone);
            fragment.appendChild(shell);
          } else {
            fragment.appendChild(clone);
          }
        } else {
          fragment.appendChild(clone);
        }
      }
      return fragment;
    }

    let outputParent = fragment;
    if (common.nodeType === Node.ELEMENT_NODE
      && ALLOWED_TAGS.has(common.tagName)
      && !BLOCKED_TAGS.has(common.tagName)
      && sourceElementIsVisible(common)
      && elementHasPotentialVisibleArea(common)) {
      const commonShell = createSafeElementShell(common, document.baseURI);
      if (commonShell) {
        fragment.appendChild(commonShell);
        outputParent = commonShell;
      }
    }

    Array.from(common.childNodes).forEach((child) => {
      const clone = cloneSelectedNode(child, range);
      if (clone) outputParent.appendChild(clone);
    });
    return fragment;
  }

  function cloneSelectedNode(sourceNode, range) {
    if (!rangeIntersectsNode(range, sourceNode)) return null;

    if (sourceNode.nodeType === Node.TEXT_NODE) {
      let start = 0;
      let end = sourceNode.length;
      if (sourceNode === range.startContainer) start = range.startOffset;
      if (sourceNode === range.endContainer) end = range.endOffset;
      if (end <= start || !sourceTextIsVisible(sourceNode, start, end)) return null;
      return document.createTextNode(sourceNode.data.slice(start, end));
    }

    if (sourceNode.nodeType !== Node.ELEMENT_NODE) return null;
    const sourceElement = sourceNode;
    if (BLOCKED_TAGS.has(sourceElement.tagName) || !sourceElementIsVisible(sourceElement)) return null;

    const isAllowed = ALLOWED_TAGS.has(sourceElement.tagName) && !sourceElement.tagName.includes('-');
    const preserveShell = isAllowed && elementHasPotentialVisibleArea(sourceElement);
    if (!preserveShell && !sourceElement.hasChildNodes()) return null;
    const output = preserveShell
      ? createSafeElementShell(sourceElement, document.baseURI)
      : document.createDocumentFragment();
    if (!output) return null;

    Array.from(sourceElement.childNodes).forEach((child) => {
      const childClone = cloneSelectedNode(child, range);
      if (childClone) output.appendChild(childClone);
    });

    return output;
  }

  function rangeIntersectsNode(range, node) {
    try {
      return range.intersectsNode(node);
    } catch (error) {
      return false;
    }
  }

  function sourceTextIsVisible(textNode, start, end) {
    const parent = textNode.parentElement;
    if (!parent || !sourceElementIsVisible(parent)) return false;

    const style = getComputedStyle(parent);
    const textFillColor = style.getPropertyValue('-webkit-text-fill-color');
    if (parseFloat(style.fontSize) === 0
      || isTransparentColor(style.color)
      || isTransparentColor(textFillColor)) {
      return false;
    }

    const textRange = document.createRange();
    try {
      textRange.setStart(textNode, start);
      textRange.setEnd(textNode, end);
      return Array.from(textRange.getClientRects()).some((rect) => rectHasPotentialVisibleArea(rect, parent));
    } catch (error) {
      return false;
    }
  }

  function elementHasPotentialVisibleArea(element) {
    const allowZeroWidth = element.tagName === 'BR';
    return Array.from(element.getClientRects()).some((rect) => (
      rectHasPotentialVisibleArea(rect, element, allowZeroWidth)
    ));
  }

  function sourceElementIsVisible(element) {
    for (let current = element; current; current = current.parentElement) {
      if (current.hidden || current.hasAttribute('inert') || current.getAttribute('aria-hidden') === 'true') return false;
      const style = getComputedStyle(current);
      if (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse') return false;
      if (style.contentVisibility === 'hidden' || parseFloat(style.opacity) === 0) return false;
      if (style.clip && style.clip !== 'auto') return false;
      if (style.clipPath && style.clipPath !== 'none') return false;
      if (filterMakesInvisible(style.filter)) return false;

      const maskImage = style.getPropertyValue('mask-image')
        || style.getPropertyValue('-webkit-mask-image');
      if (maskImage && maskImage !== 'none') return false;
    }
    return true;
  }

  function isTransparentColor(value) {
    if (!value) return false;
    const normalized = value.trim().toLowerCase();
    if (normalized === 'transparent') return true;
    return /^rgba\([^)]*,\s*0(?:\.0+)?\s*\)$/i.test(normalized)
      || /^(?:rgb|rgba|color)\([^)]*\/\s*0(?:\.0+)?%?\s*\)$/i.test(normalized);
  }

  function filterMakesInvisible(value) {
    return /(?:^|\s)opacity\(\s*0(?:\.0+)?%?\s*\)/i.test(value || '');
  }

  function rectHasPotentialVisibleArea(rect, element, allowZeroWidth = false) {
    const adjustedRight = allowZeroWidth && rect.right - rect.left <= 0.1
      ? rect.left + 1
      : rect.right;
    const visible = {
      left: rect.left,
      right: adjustedRight,
      top: rect.top,
      bottom: rect.bottom
    };
    if (!hasPositiveArea(visible)) return false;

    for (let current = element; current; current = current.parentElement) {
      if (current === document.documentElement || current === document.body || current === document.scrollingElement) {
        continue;
      }

      const style = getComputedStyle(current);
      if (style.display === 'inline' || style.display === 'contents') continue;
      const paintClip = containsPaint(style.contain);
      const paddingBox = elementPaddingBox(current);

      if (paintClip || clipsCurrentOverflow(style.overflowX)) {
        intersectRect(visible, paddingBox, true, false);
      } else if (isScrollableOverflow(style.overflowX)) {
        exposeScrollableAxis(visible, paddingBox, current, 'x');
      }

      if (paintClip || clipsCurrentOverflow(style.overflowY)) {
        intersectRect(visible, paddingBox, false, true);
      } else if (isScrollableOverflow(style.overflowY)) {
        exposeScrollableAxis(visible, paddingBox, current, 'y');
      }

      if (!hasPositiveArea(visible)) return false;
    }

    const canvas = hasFixedAncestor(element)
      ? { left: 0, top: 0, right: window.innerWidth, bottom: window.innerHeight }
      : documentCanvasRect();
    intersectRect(visible, canvas, true, true);
    return hasPositiveArea(visible);
  }

  function hasFixedAncestor(element) {
    for (let current = element; current; current = current.parentElement) {
      if (getComputedStyle(current).position === 'fixed') return true;
    }
    return false;
  }

  function documentCanvasRect() {
    const root = document.documentElement;
    const body = document.body;
    const rootRect = root.getBoundingClientRect();
    const left = Math.min(0, rootRect.left);
    const top = Math.min(0, rootRect.top);
    const width = Math.max(window.innerWidth, root.scrollWidth, body?.scrollWidth || 0);
    const height = Math.max(window.innerHeight, root.scrollHeight, body?.scrollHeight || 0);
    return {
      left,
      top,
      right: Math.max(window.innerWidth, left + width),
      bottom: Math.max(window.innerHeight, top + height)
    };
  }

  function clipsCurrentOverflow(value) {
    return value === 'hidden' || value === 'clip';
  }

  function isScrollableOverflow(value) {
    return value === 'scroll' || value === 'auto';
  }

  function containsPaint(value) {
    const tokens = (value || '').toLowerCase().split(/\s+/);
    return tokens.includes('paint') || tokens.includes('content') || tokens.includes('strict');
  }

  function exposeScrollableAxis(target, clip, element, axis) {
    const horizontal = axis === 'x';
    const startKey = horizontal ? 'left' : 'top';
    const endKey = horizontal ? 'right' : 'bottom';
    const clientSize = horizontal ? element.clientWidth : element.clientHeight;
    const scrollSize = horizontal ? element.scrollWidth : element.scrollHeight;
    const currentScroll = horizontal ? element.scrollLeft : element.scrollTop;
    const scrollExtent = Math.max(0, scrollSize - clientSize);
    const rect = element.getBoundingClientRect();
    const layoutSize = horizontal ? element.offsetWidth : element.offsetHeight;
    const paintedSize = horizontal ? rect.width : rect.height;
    const scale = layoutSize > 0 ? paintedSize / layoutSize : 1;
    const rtl = horizontal && getComputedStyle(element).direction === 'rtl';
    const minScroll = rtl ? -scrollExtent : 0;
    const maxScroll = rtl ? 0 : scrollExtent;

    const potentialStart = target[startKey] + (currentScroll - maxScroll) * scale;
    const potentialEnd = target[endKey] + (currentScroll - minScroll) * scale;
    target[startKey] = Math.max(potentialStart, clip[startKey]);
    target[endKey] = Math.min(potentialEnd, clip[endKey]);
  }

  function elementPaddingBox(element) {
    const rect = element.getBoundingClientRect();
    const scaleX = element.offsetWidth > 0 ? rect.width / element.offsetWidth : 1;
    const scaleY = element.offsetHeight > 0 ? rect.height / element.offsetHeight : 1;
    const left = rect.left + element.clientLeft * scaleX;
    const top = rect.top + element.clientTop * scaleY;
    return {
      left,
      top,
      right: left + element.clientWidth * scaleX,
      bottom: top + element.clientHeight * scaleY
    };
  }

  function intersectRect(target, clip, clipX, clipY) {
    if (clipX) {
      target.left = Math.max(target.left, clip.left);
      target.right = Math.min(target.right, clip.right);
    }
    if (clipY) {
      target.top = Math.max(target.top, clip.top);
      target.bottom = Math.min(target.bottom, clip.bottom);
    }
  }

  function hasPositiveArea(rect) {
    return rect.right - rect.left > 0.1 && rect.bottom - rect.top > 0.1;
  }

  function createSafeElementShell(source, baseUri) {
    const target = document.createElement(source.tagName.toLowerCase());
    const tagSpecific = TAG_ATTRIBUTES[source.tagName] || new Set();

    Array.from(source.attributes).forEach((attribute) => {
      const name = attribute.name.toLowerCase();
      if (!COMMON_ATTRIBUTES.has(name) && !tagSpecific.has(name)) return;

      if (name === 'style') {
        const safeStyle = sanitizeStyle(attribute.value);
        if (safeStyle) target.setAttribute('style', safeStyle);
        return;
      }

      if (name === 'href' || name === 'cite') {
        const safeValue = safeUrl(attribute.value, baseUri, 'link');
        if (safeValue) target.setAttribute(name, safeValue);
        return;
      }

      if (name === 'src') {
        const safeValue = safeUrl(attribute.value, baseUri, 'image');
        if (safeValue) target.setAttribute('src', safeValue);
        return;
      }

      target.setAttribute(name, attribute.value);
    });

    applyComputedPresentation(source, target);

    if (source.tagName === 'IMG') {
      const preferredSource = source.currentSrc
        || source.getAttribute('src')
        || source.getAttribute('data-src')
        || source.getAttribute('data-original');
      const safeSource = safeUrl(preferredSource, baseUri, 'image');
      if (safeSource) target.setAttribute('src', safeSource);
    }

    if (source.tagName === 'IMG' && !target.hasAttribute('src')) {
      const replacement = document.createElement('span');
      const alt = source.getAttribute('alt')?.trim();
      replacement.textContent = alt ? `[图片：${alt}]` : '[图片无法复制]';
      return replacement;
    }

    return target;
  }

  function applyComputedPresentation(source, target) {
    const computed = getComputedStyle(source);
    if (computed.direction === 'rtl' && !target.hasAttribute('dir')) target.setAttribute('dir', 'rtl');

    COMPUTED_STYLE_PROPERTIES.forEach((property) => {
      const value = computed.getPropertyValue(property).trim();
      if (!value || /url\s*\(|expression\s*\(/i.test(value)) return;
      if (property === 'background-color' && (value === 'transparent' || /rgba\([^)]*,\s*0\s*\)$/.test(value))) return;
      if (property.startsWith('border-') && (value.includes(' none ') || value.startsWith('0px '))) return;
      if ((property.startsWith('padding-') || property.startsWith('margin-')) && value === '0px') return;
      if (['normal', 'none', 'auto', 'start'].includes(value)) return;
      if (value.length > 400) return;
      target.style.setProperty(property, value);
    });
  }

  function snapshotRange(range) {
    const cloned = cloneVisibleRange(range);
    const sanitized = sanitizeFragment(cloned, document.baseURI);
    const text = fragmentToPlainText(sanitized).replace(/^\n+|\n+$/g, '');
    const hasVisualContent = Boolean(sanitized.querySelector?.('img,hr,table'));
    if (!text.replace(/\s/g, '') && !hasVisualContent) throw new Error('没有选中有效内容，请重新选择。');

    const wrapper = document.createElement('div');
    wrapper.appendChild(sanitized.cloneNode(true));
    const html = wrapper.innerHTML;
    const byteSize = new TextEncoder().encode(html + text).byteLength;
    if (!html || byteSize > MAX_TOTAL_BYTES) {
      throw new Error('这个片段过大，暂时无法加入中转站。');
    }

    const compactText = text.replace(/\s+/g, ' ').trim();
    const compactGraphemes = segmentGraphemes(compactText);
    const fallbackPreview = wrapper.querySelector('img')?.getAttribute('alt') || '图片内容';
    const previewText = compactGraphemes.length > 30
      ? `${sliceGraphemeList(compactText, compactGraphemes, 15, false)} ··· ··· ${sliceGraphemeList(compactText, compactGraphemes, 15, true)}`
      : (compactText || fallbackPreview);

    return {
      id: nextSegmentId++,
      html,
      text,
      previewText,
      sourceTitle: document.title || location.hostname || '当前页面',
      selected: true,
      byteSize
    };
  }

  function sliceGraphemeList(text, graphemes, count, fromEnd) {
    if (!graphemes.length) return '';
    if (!fromEnd) {
      const last = graphemes[Math.min(count, graphemes.length) - 1];
      return text.slice(0, last.end);
    }
    const first = graphemes[Math.max(0, graphemes.length - count)];
    return text.slice(first.start);
  }

  function sanitizeFragment(fragment, baseUri) {
    const unsafeNodes = [];
    const nodeWalker = document.createTreeWalker(fragment, NodeFilter.SHOW_ALL);
    let currentNode = nodeWalker.nextNode();
    while (currentNode) {
      if (currentNode.nodeType !== Node.ELEMENT_NODE && currentNode.nodeType !== Node.TEXT_NODE) {
        unsafeNodes.push(currentNode);
      }
      currentNode = nodeWalker.nextNode();
    }
    unsafeNodes.forEach((node) => node.remove());

    const elements = Array.from(fragment.querySelectorAll?.('*') || []);
    elements.forEach((element) => {
      const tag = element.tagName;
      if (BLOCKED_TAGS.has(tag)) {
        element.remove();
        return;
      }

      if (!ALLOWED_TAGS.has(tag) || tag.includes('-')) {
        element.replaceWith(...Array.from(element.childNodes));
        return;
      }

      sanitizeAttributes(element, baseUri);
    });
    return fragment;
  }

  function sanitizeAttributes(element, baseUri) {
    const tagSpecific = TAG_ATTRIBUTES[element.tagName] || new Set();
    Array.from(element.attributes).forEach((attribute) => {
      const name = attribute.name.toLowerCase();
      if (!COMMON_ATTRIBUTES.has(name) && !tagSpecific.has(name)) {
        element.removeAttribute(attribute.name);
        return;
      }

      if (name === 'style') {
        const safeStyle = sanitizeStyle(attribute.value);
        if (safeStyle) element.setAttribute('style', safeStyle);
        else element.removeAttribute('style');
      }
    });

    if (element.tagName === 'A' && element.hasAttribute('href')) {
      const safeHref = safeUrl(element.getAttribute('href'), baseUri, 'link');
      if (safeHref) element.setAttribute('href', safeHref);
      else element.removeAttribute('href');
    }

    if ((element.tagName === 'BLOCKQUOTE' || element.tagName === 'Q') && element.hasAttribute('cite')) {
      const safeCite = safeUrl(element.getAttribute('cite'), baseUri, 'link');
      if (safeCite) element.setAttribute('cite', safeCite);
      else element.removeAttribute('cite');
    }

    if (element.tagName === 'IMG') {
      const safeSrc = safeUrl(element.getAttribute('src'), baseUri, 'image');
      if (safeSrc) element.setAttribute('src', safeSrc);
      else {
        const replacement = document.createElement('span');
        const alt = element.getAttribute('alt')?.trim();
        replacement.textContent = alt ? `[图片：${alt}]` : '[图片无法复制]';
        element.replaceWith(replacement);
      }
    }
  }

  function sanitizeStyle(rawStyle) {
    if (!rawStyle || /url\s*\(|expression\s*\(|@import|-moz-binding|behavior\s*:/i.test(rawStyle)) return '';
    const scratch = document.createElement('span');
    scratch.style.cssText = rawStyle;
    const safeDeclarations = [];
    for (const property of Array.from(scratch.style)) {
      if (!SAFE_STYLE_PROPERTIES.has(property)) continue;
      const value = scratch.style.getPropertyValue(property);
      const priority = scratch.style.getPropertyPriority(property);
      if (/url\s*\(|expression\s*\(/i.test(value)) continue;
      safeDeclarations.push(`${property}: ${value}${priority ? ' !important' : ''}`);
    }
    return safeDeclarations.join('; ');
  }

  function safeUrl(rawValue, baseUri, type) {
    if (!rawValue) return '';
    try {
      const url = new URL(rawValue, baseUri);
      const allowedProtocols = type === 'image'
        ? new Set(['http:', 'https:'])
        : new Set(['http:', 'https:', 'mailto:', 'tel:']);
      return allowedProtocols.has(url.protocol) ? url.href : '';
    } catch (error) {
      return '';
    }
  }

  function fragmentToPlainText(fragment) {
    let output = '';
    const appendBreak = () => {
      if (!output.endsWith('\n')) output += '\n';
    };

    const walk = (node) => {
      if (node.nodeType === Node.TEXT_NODE) {
        output += node.data;
        return;
      }
      if (node.nodeType !== Node.ELEMENT_NODE && node.nodeType !== Node.DOCUMENT_FRAGMENT_NODE) return;

      const tag = node.nodeType === Node.ELEMENT_NODE ? node.tagName : '';
      if (tag === 'BR') {
        appendBreak();
        return;
      }
      if (tag === 'IMG') {
        output += node.getAttribute('alt') ? `[图片：${node.getAttribute('alt')}]` : '[图片]';
        return;
      }
      if (tag === 'HR') {
        appendBreak();
        output += '────────';
        appendBreak();
        return;
      }

      const isBlock = BLOCK_TEXT_TAGS.has(tag);
      if (isBlock && output && !output.endsWith('\n')) appendBreak();
      if (tag === 'LI') output += '• ';
      Array.from(node.childNodes).forEach(walk);
      if (tag === 'TD' || tag === 'TH') output += '\t';
      if (isBlock) appendBreak();
    };

    walk(fragment);
    return output.replace(/\t+\n/g, '\n').replace(/\n{3,}/g, '\n\n');
  }

  function totalStoredBytes() {
    return segments.reduce((total, segment) => total + segment.byteSize, 0);
  }

  function showToast(message, actionLabel = '', callback = null) {
    window.clearTimeout(toastTimer);
    toastText.textContent = message;
    toastAction.textContent = actionLabel;
    toastAction.style.display = actionLabel ? 'inline-flex' : 'none';
    toastCallback = callback;
    toast.classList.add('is-visible');
    toastTimer = window.setTimeout(() => {
      toast.classList.remove('is-visible');
      toastCallback = null;
    }, actionLabel ? 9000 : 3200);
  }

  function clearSuccessPulse() {
    window.clearTimeout(successPulseTimer);
    successPulseTimer = 0;
    newButton.classList.remove('es-success-pulse');
    miniNewButton.classList.remove('es-success-pulse');
    miniExpandButton.classList.remove('es-success-pulse');
  }

  function pulseNewSegmentSuccess() {
    clearSuccessPulse();
    const target = minimized
      ? (floatingMode === 'single' ? miniExpandButton : miniNewButton)
      : newButton;
    void target.offsetWidth;
    target.classList.add('es-success-pulse');
    successPulseTimer = window.setTimeout(() => {
      target.classList.remove('es-success-pulse');
      successPulseTimer = 0;
    }, 500);
  }

  function closeAndReset() {
    stationRevision += 1;
    segments = [];
    nextSegmentId = 1;
    minimized = false;
    panelView = 'station';
    cardDrag = null;
    manualCopyPending = false;
    copyStatus.textContent = '';
    copyStatus.classList.remove('is-error');
    window.clearTimeout(toastTimer);
    clearSuccessPulse();
    toastCallback = null;
    toast.classList.remove('is-visible');
    setVisible(false);
  }

  function clampPanelToViewport() {
    const rect = panel.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const left = Math.min(Math.max(8, rect.left), Math.max(8, window.innerWidth - rect.width - 8));
    const top = Math.min(Math.max(8, rect.top), Math.max(8, window.innerHeight - Math.min(rect.height, window.innerHeight - 16) - 8));
    panel.style.left = `${left}px`;
    panel.style.top = `${top}px`;
    panel.style.right = 'auto';
  }

  function positionMiniStackFromPanel() {
    const rect = panel.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const stackHeight = floatingMode === 'single' ? 48 : 104;
    miniStack.style.left = `${Math.min(Math.max(8, rect.right - 48), Math.max(8, window.innerWidth - 56))}px`;
    miniStack.style.top = `${Math.min(Math.max(8, rect.top), Math.max(8, window.innerHeight - stackHeight - 8))}px`;
    miniStack.style.right = 'auto';
  }

  function clampMiniStackToViewport() {
    const rect = miniStack.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const left = Math.min(Math.max(8, rect.left), Math.max(8, window.innerWidth - rect.width - 8));
    const top = Math.min(Math.max(8, rect.top), Math.max(8, window.innerHeight - rect.height - 8));
    miniStack.style.left = `${left}px`;
    miniStack.style.top = `${top}px`;
    miniStack.style.right = 'auto';
  }

  function enablePanelDragging() {
    let dragging = null;
    dragHandle.addEventListener('pointerdown', (event) => {
      if (!isTrustedInteraction(event) || event.button !== 0 || event.target.closest('button')) return;
      const rect = panel.getBoundingClientRect();
      dragging = { pointerId: event.pointerId, offsetX: event.clientX - rect.left, offsetY: event.clientY - rect.top };
      panel.style.left = `${rect.left}px`;
      panel.style.top = `${rect.top}px`;
      panel.style.right = 'auto';
      dragHandle.setPointerCapture(event.pointerId);
      event.preventDefault();
    });

    dragHandle.addEventListener('pointermove', (event) => {
      if (!isTrustedInteraction(event) || !dragging || dragging.pointerId !== event.pointerId) return;
      const rect = panel.getBoundingClientRect();
      const left = Math.min(Math.max(8, event.clientX - dragging.offsetX), Math.max(8, window.innerWidth - rect.width - 8));
      const top = Math.min(Math.max(8, event.clientY - dragging.offsetY), Math.max(8, window.innerHeight - 48));
      panel.style.left = `${left}px`;
      panel.style.top = `${top}px`;
    });

    const endDrag = (event) => {
      if (!isTrustedInteraction(event) || !dragging || dragging.pointerId !== event.pointerId) return;
      dragging = null;
      clampPanelToViewport();
    };
    dragHandle.addEventListener('pointerup', endDrag);
    dragHandle.addEventListener('pointercancel', endDrag);
  }

  function enableMiniStackDragging() {
    const dragThreshold = 5;
    let dragging = null;
    let suppressClickUntil = 0;

    miniStack.addEventListener('pointerdown', (event) => {
      if (!isTrustedInteraction(event) || event.button !== 0) return;
      const rect = miniStack.getBoundingClientRect();
      dragging = {
        pointerId: event.pointerId,
        captureTarget: event.target.closest?.('.es-float-tile') || miniStack,
        startX: event.clientX,
        startY: event.clientY,
        startLeft: rect.left,
        startTop: rect.top,
        width: rect.width,
        height: rect.height,
        moved: false
      };
      miniStack.style.left = `${rect.left}px`;
      miniStack.style.top = `${rect.top}px`;
      miniStack.style.right = 'auto';
      try {
        dragging.captureTarget.setPointerCapture(event.pointerId);
      } catch (error) {
        // Dragging still works while the pointer remains over the button stack.
      }
    });

    miniStack.addEventListener('pointermove', (event) => {
      if (!isTrustedInteraction(event) || !dragging || dragging.pointerId !== event.pointerId) return;
      const deltaX = event.clientX - dragging.startX;
      const deltaY = event.clientY - dragging.startY;
      if (!dragging.moved && Math.hypot(deltaX, deltaY) < dragThreshold) return;

      dragging.moved = true;
      miniStack.classList.add('is-dragging');
      const left = Math.min(
        Math.max(8, dragging.startLeft + deltaX),
        Math.max(8, window.innerWidth - dragging.width - 8)
      );
      const top = Math.min(
        Math.max(8, dragging.startTop + deltaY),
        Math.max(8, window.innerHeight - dragging.height - 8)
      );
      miniStack.style.left = `${left}px`;
      miniStack.style.top = `${top}px`;
      event.preventDefault();
    });

    const endDrag = (event) => {
      if (!dragging || dragging.pointerId !== event.pointerId) return;
      const activeDrag = dragging;
      const moved = activeDrag.moved;
      dragging = null;
      miniStack.classList.remove('is-dragging');
      try {
        activeDrag.captureTarget.releasePointerCapture(event.pointerId);
      } catch (error) {
        // Pointer capture may already have ended.
      }
      if (moved) {
        suppressClickUntil = performance.now() + 450;
        event.preventDefault();
      }
      clampMiniStackToViewport();
    };

    miniStack.addEventListener('pointerup', endDrag);
    miniStack.addEventListener('pointercancel', endDrag);
    miniStack.addEventListener('click', (event) => {
      if (!isTrustedInteraction(event) || performance.now() >= suppressClickUntil) return;
      blockPageEvent(event);
    }, true);
  }

  function beginCardDrag(event) {
    const handle = event.target.closest('button[data-action="drag"]');
    if (!isTrustedInteraction(event) || !handle || event.button !== 0 || cardDrag) return;
    const card = handle.closest('.es-card');
    if (!card) return;

    cardDrag = {
      pointerId: event.pointerId,
      handle,
      card,
      originalIds: segments.map((segment) => segment.id)
    };
    card.classList.add('is-dragging');
    try {
      handle.setPointerCapture(event.pointerId);
    } catch (error) {
      // Some embedded test surfaces do not expose native pointer capture.
    }
    event.preventDefault();
    event.stopPropagation();
  }

  function moveCardDrag(event) {
    if (!isTrustedInteraction(event) || !cardDrag || cardDrag.pointerId !== event.pointerId) return;
    const { card } = cardDrag;
    const listRect = list.getBoundingClientRect();
    if (event.clientY < listRect.top + 30) list.scrollTop -= 14;
    if (event.clientY > listRect.bottom - 30) list.scrollTop += 14;

    const otherCards = Array.from(list.querySelectorAll('.es-card')).filter((item) => item !== card);
    const before = otherCards.find((item) => {
      const rect = item.getBoundingClientRect();
      return event.clientY < rect.top + rect.height / 2;
    });
    if (before) list.insertBefore(card, before);
    else list.appendChild(card);
    event.preventDefault();
  }

  function endCardDrag(event, cancelled = false) {
    if (!cardDrag || cardDrag.pointerId !== event.pointerId) return;
    const activeDrag = cardDrag;
    cardDrag = null;
    activeDrag.card.classList.remove('is-dragging');
    try {
      activeDrag.handle.releasePointerCapture(event.pointerId);
    } catch (error) {
      // Pointer capture may already have been released by the browser.
    }

    if (!cancelled) {
      const byId = new Map(segments.map((segment) => [segment.id, segment]));
      const ordered = Array.from(list.querySelectorAll('.es-card'))
        .map((card) => byId.get(Number(card.dataset.segmentId)))
        .filter(Boolean);
      if (ordered.length === segments.length) segments = ordered;
    }
    copyStatus.textContent = '';
    render();
  }

  function moveCardWithKeyboard(event) {
    const handle = event.target.closest('button[data-action="drag"]');
    if (!isTrustedInteraction(event) || !handle || (event.key !== 'ArrowUp' && event.key !== 'ArrowDown')) return;
    const card = handle.closest('.es-card');
    const index = segments.findIndex((segment) => segment.id === Number(card?.dataset.segmentId));
    const nextIndex = event.key === 'ArrowUp' ? index - 1 : index + 1;
    if (index < 0 || nextIndex < 0 || nextIndex >= segments.length) return;
    event.preventDefault();
    [segments[index], segments[nextIndex]] = [segments[nextIndex], segments[index]];
    const movedId = segments[nextIndex].id;
    render();
    requestAnimationFrame(() => {
      list.querySelector(`.es-card[data-segment-id="${movedId}"] button[data-action="drag"]`)?.focus();
    });
  }

  function composeClipboardPayload(chosen) {
    const text = chosen.map((segment) => segment.text).join('\n\n');
    const html = chosen.map((segment) => `<section>${segment.html}</section>`).join('<p><br></p>');
    const bytes = new TextEncoder().encode(html + text).byteLength;
    if (bytes > MAX_TOTAL_BYTES) throw new RangeError('所选内容超过 8 MB，请减少片段后重试。');
    return { html, text };
  }

  function enqueueClipboardWrite(chosen) {
    let payload;
    try {
      payload = composeClipboardPayload(chosen);
    } catch (error) {
      return Promise.reject(error);
    }

    const queuedRevision = stationRevision;
    const task = clipboardQueue.then(async () => {
      // Closing the station invalidates clipboard work that has not started yet.
      if (queuedRevision !== stationRevision) return;
      const response = await chrome.runtime.sendMessage({
        target: 'service-worker',
        type: 'EXCERPT_STATION_WRITE_CLIPBOARD',
        ...payload
      });
      if (!response?.ok) throw new Error(response?.error || '浏览器拒绝了剪贴板写入。');
    });
    clipboardQueue = task.catch(() => {});
    return task;
  }

  settingsButton.addEventListener('click', (event) => {
    if (!isTrustedInteraction(event)) return;
    if (captureMode !== 'idle') cancelCapture();
    panelView = panelView === 'station' ? 'settings' : 'station';
    render();
  });

  guideOpenButton.addEventListener('click', (event) => {
    if (!isTrustedInteraction(event)) return;
    panelView = 'guide';
    render();
    guideBackButton.focus();
  });

  guideBackButton.addEventListener('click', (event) => {
    if (!isTrustedInteraction(event)) return;
    panelView = 'settings';
    render();
    guideOpenButton.focus();
  });

  colorInputs.forEach((input) => {
    input.addEventListener('change', (event) => {
      if (!isTrustedInteraction(event) || !input.checked) return;
      applySelectionColor(input.value, { persist: true });
    });
  });

  floatingModeInputs.forEach((input) => {
    input.addEventListener('change', (event) => {
      if (!isTrustedInteraction(event) || !input.checked) return;
      applyFloatingMode(input.value, { persist: true });
    });
  });

  chrome.storage?.onChanged?.addListener?.((changes, areaName) => {
    if (areaName !== 'local') return;
    const colorChange = changes?.[SELECTION_COLOR_STORAGE_KEY];
    const floatingModeChange = changes?.[FLOATING_MODE_STORAGE_KEY];
    if (colorChange) applySelectionColor(colorChange.newValue);
    if (floatingModeChange) applyFloatingMode(floatingModeChange.newValue);
  });

  newButton.addEventListener('click', (event) => {
    if (!isTrustedInteraction(event)) return;
    if (captureMode === 'idle') beginCapture();
    else cancelCapture();
  });

  minimizeButton.addEventListener('click', (event) => {
    if (!isTrustedInteraction(event)) return;
    positionMiniStackFromPanel();
    minimized = true;
    render();
    clampMiniStackToViewport();
  });

  closeButton.addEventListener('click', (event) => {
    if (isTrustedInteraction(event)) closeAndReset();
  });

  miniExpandButton.addEventListener('click', (event) => {
    if (!isTrustedInteraction(event)) return;
    if (floatingMode === 'single') {
      if (captureMode === 'idle') beginCapture();
      else cancelCapture();
      return;
    }
    minimized = false;
    panelView = 'station';
    render();
    clampPanelToViewport();
    minimizeButton.focus();
  });

  miniExpandButton.addEventListener('contextmenu', (event) => {
    if (!isTrustedInteraction(event) || floatingMode !== 'single') return;
    blockPageEvent(event);
    minimized = false;
    panelView = 'station';
    render();
    clampPanelToViewport();
    minimizeButton.focus();
  });

  miniNewButton.addEventListener('click', (event) => {
    if (!isTrustedInteraction(event)) return;
    if (captureMode === 'idle') beginCapture();
    else cancelCapture();
  });

  selectAll.addEventListener('change', (event) => {
    if (!isTrustedInteraction(event)) return;
    segments.forEach((segment) => { segment.selected = selectAll.checked; });
    copyStatus.textContent = '';
    render();
  });

  list.addEventListener('change', (event) => {
    if (!isTrustedInteraction(event) || event.target.dataset.action !== 'select') return;
    const card = event.target.closest('.es-card');
    const segment = segments.find((item) => item.id === Number(card?.dataset.segmentId));
    if (segment) segment.selected = event.target.checked;
    copyStatus.textContent = '';
    render();
  });

  list.addEventListener('click', (event) => {
    if (!isTrustedInteraction(event)) return;
    const button = event.target.closest('button[data-action]');
    const card = event.target.closest('.es-card');
    if (!button || !card) return;
    const index = segments.findIndex((item) => item.id === Number(card.dataset.segmentId));
    if (index < 0) return;

    if (button.dataset.action === 'drag') return;
    if (button.dataset.action === 'delete') {
      const [removed] = segments.splice(index, 1);
      showToast('已删除一个片段。', '撤销', () => {
        if (segments.length >= MAX_SEGMENTS || totalStoredBytes() + removed.byteSize > MAX_TOTAL_BYTES) {
          showToast('当前中转站已满，无法恢复这个片段。');
          return;
        }
        segments.splice(Math.min(index, segments.length), 0, removed);
        render();
      });
    }

    copyStatus.textContent = '';
    render();
  });

  deleteSelectedButton.addEventListener('click', (event) => {
    if (!isTrustedInteraction(event)) return;
    const removed = segments
      .map((segment, index) => ({ segment, index }))
      .filter(({ segment }) => segment.selected);
    if (!removed.length) return;

    const removedIds = new Set(removed.map(({ segment }) => segment.id));
    segments = segments.filter((segment) => !removedIds.has(segment.id));
    copyStatus.textContent = '';
    render();

    showToast(`已删除 ${removed.length} 个片段。`, '撤销', () => {
      const removedBytes = removed.reduce((total, item) => total + item.segment.byteSize, 0);
      if (segments.length + removed.length > MAX_SEGMENTS || totalStoredBytes() + removedBytes > MAX_TOTAL_BYTES) {
        showToast('当前中转站已满，无法恢复这些片段。');
        return;
      }
      removed.forEach(({ segment, index }) => {
        segments.splice(Math.min(index, segments.length), 0, segment);
      });
      copyStatus.textContent = '';
      render();
    });
  });

  copyButton.addEventListener('click', async (event) => {
    if (!isTrustedInteraction(event)) return;
    const chosen = segments.filter((segment) => segment.selected);
    if (!chosen.length) return;

    const revision = stationRevision;
    manualCopyPending = true;
    copyStatus.classList.remove('is-error');
    copyStatus.textContent = '正在写入剪贴板…';
    render();

    try {
      await enqueueClipboardWrite(chosen);
      if (revision !== stationRevision) return;
      copyStatus.textContent = `已按当前顺序复制 ${chosen.length} 段。`;
    } catch (error) {
      if (revision !== stationRevision) return;
      copyStatus.classList.add('is-error');
      copyStatus.textContent = `复制失败：${error?.message || '未知错误'}`;
    } finally {
      if (revision === stationRevision) {
        manualCopyPending = false;
        render();
      }
    }
  });

  toastAction.addEventListener('click', (event) => {
    if (!isTrustedInteraction(event)) return;
    const callback = toastCallback;
    toast.classList.remove('is-visible');
    toastCallback = null;
    window.clearTimeout(toastTimer);
    callback?.();
  });

  list.addEventListener('pointerdown', beginCardDrag);
  list.addEventListener('pointermove', moveCardDrag);
  list.addEventListener('pointerup', (event) => endCardDrag(event, false));
  list.addEventListener('pointercancel', (event) => endCardDrag(event, true));
  list.addEventListener('keydown', moveCardWithKeyboard);

  document.addEventListener('pointermove', handlePointerMove, true);
  document.addEventListener('pointerdown', handleCapturePointerDown, true);
  document.addEventListener('pointerup', handleCapturePointerUp, true);
  document.addEventListener('pointercancel', handleCapturePointerCancel, true);
  ['mousedown', 'mouseup', 'click', 'dblclick', 'auxclick', 'dragstart', 'selectstart'].forEach((eventName) => {
    document.addEventListener(eventName, handleFollowupPageEvent, true);
  });
  document.addEventListener('keydown', handleKeyDown, true);
  captureShield.addEventListener('pointermove', (event) => handlePointerMove(event, true));
  captureShield.addEventListener('pointerdown', (event) => handleCapturePointerDown(event, true));
  captureShield.addEventListener('pointerup', (event) => handleCapturePointerUp(event, true));
  captureShield.addEventListener('pointercancel', (event) => handleCapturePointerCancel(event, true));
  captureShield.addEventListener('wheel', handleShieldWheel, { passive: false });
  ['mousedown', 'mouseup', 'click', 'dblclick', 'auxclick', 'dragstart', 'selectstart', 'contextmenu'].forEach((eventName) => {
    captureShield.addEventListener(eventName, handleShieldFollowupEvent);
  });
  document.addEventListener('scroll', () => scheduleMarkerUpdate(true), true);
  window.addEventListener('resize', () => {
    if (minimized) clampMiniStackToViewport();
    else clampPanelToViewport();
    scheduleMarkerUpdate(true);
  });
  window.visualViewport?.addEventListener('resize', () => scheduleMarkerUpdate(true));
  window.visualViewport?.addEventListener('scroll', () => scheduleMarkerUpdate(true));

  enablePanelDragging();
  enableMiniStackDragging();
  render();
  void loadSelectionColorPreference();
  void loadFloatingModePreference();

  const reattachObserver = new MutationObserver(() => {
    if (!host.isConnected) document.documentElement.appendChild(host);
  });
  try {
    reattachObserver.observe(document.documentElement, { childList: true });
  } catch (error) {
    // Some embedded browser realms expose a cross-realm document root.
  }
})();
