chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.target !== 'offscreen' || message?.type !== 'EXCERPT_STATION_OFFSCREEN_WRITE') {
    return false;
  }

  writeRichClipboard(message.html, message.text)
    .then(() => sendResponse({ ok: true }))
    .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));

  return true;
});

async function writeRichClipboard(html, text) {
  const copied = copyWithClipboardEvent(html, text);
  if (!copied) throw new Error('当前浏览器不支持富文本剪贴板写入。');
}

function copyWithClipboardEvent(html, text) {
  const sentinel = document.querySelector('#clipboard-sentinel');
  let handled = false;

  const onCopy = (event) => {
    if (!event.clipboardData) return;
    event.preventDefault();
    event.clipboardData.setData('text/html', html);
    event.clipboardData.setData('text/plain', text);
    handled = true;
  };

  document.addEventListener('copy', onCopy, { capture: true, once: true });

  try {
    sentinel.value = text || ' ';
    sentinel.select();
    const copied = document.execCommand('copy');
    return copied && handled;
  } finally {
    document.removeEventListener('copy', onCopy, true);
    sentinel.value = '';
  }
}
